# Gunicorn — production configuration
# Run: gunicorn -c gunicorn.conf.py app:app

import os, multiprocessing

bind         = f"0.0.0.0:{os.getenv('PORT','5000')}"
backlog      = 2048
workers      = min(multiprocessing.cpu_count() * 2 + 1, 9)
worker_class = "eventlet"
threads      = 1
timeout      = 120
keepalive    = 5
max_requests = 1000
max_requests_jitter = 100

loglevel     = os.getenv("LOG_LEVEL","info")
accesslog    = "logs/access.log"
errorlog     = "logs/error.log"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s %(D)sµs'

proc_name    = "soc_platform"
limit_request_line   = 4096
limit_request_fields = 100
forwarded_allow_ips  = "*"

def on_starting(server):
    server.log.info("SOC Automation Platform starting...")

def on_exit(server):
    server.log.info("SOC Automation Platform stopped.")
