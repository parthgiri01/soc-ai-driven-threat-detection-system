"""
SOC SaaS Platform — Multi-Tenant Database Models
Each Tenant = one client company with isolated data.
Tables: Tenant, TenantUser, Incident, AuditLog, Subscription, AgentToken
"""
import os, json, secrets
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import UserMixin

db     = SQLAlchemy()
bcrypt = Bcrypt()


# ── Tenant (one per client company) ───────────────────────────
class Tenant(db.Model):
    __tablename__ = "tenants"
    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(120), nullable=False)
    slug          = db.Column(db.String(80), unique=True, nullable=False, index=True)
    domain        = db.Column(db.String(120), nullable=True)   # their custom domain
    plan          = db.Column(db.String(20), default="starter") # starter/pro/enterprise
    is_active     = db.Column(db.Boolean, default=True)
    # Stripe
    stripe_customer_id     = db.Column(db.String(100), nullable=True)
    stripe_subscription_id = db.Column(db.String(100), nullable=True)
    subscription_status    = db.Column(db.String(20), default="trialing")
    trial_ends_at          = db.Column(db.DateTime, nullable=True)
    # Settings
    settings      = db.Column(db.Text, default="{}")  # JSON blob
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    # Relations
    users         = db.relationship("TenantUser", back_populates="tenant", cascade="all, delete-orphan")
    incidents     = db.relationship("Incident",   back_populates="tenant", cascade="all, delete-orphan")
    audit_logs    = db.relationship("AuditLog",   back_populates="tenant", cascade="all, delete-orphan")
    agent_tokens  = db.relationship("AgentToken", back_populates="tenant", cascade="all, delete-orphan")

    def get_settings(self):
        try: return json.loads(self.settings or "{}")
        except: return {}

    def set_setting(self, key, value):
        s = self.get_settings()
        s[key] = value
        self.settings = json.dumps(s)

    @property
    def is_on_trial(self):
        if self.subscription_status == "trialing" and self.trial_ends_at:
            return datetime.utcnow() < self.trial_ends_at
        return False

    @property
    def is_paid(self):
        return self.subscription_status in ("active", "trialing")

    def __repr__(self):
        return f"<Tenant {self.slug} [{self.plan}]>"


# ── Tenant User ────────────────────────────────────────────────
class TenantUser(UserMixin, db.Model):
    __tablename__ = "tenant_users"
    id            = db.Column(db.Integer, primary_key=True)
    tenant_id     = db.Column(db.Integer, db.ForeignKey("tenants.id"), nullable=False)
    username      = db.Column(db.String(64), nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role          = db.Column(db.String(20), default="analyst")  # superadmin/admin/analyst/viewer
    is_active     = db.Column(db.Boolean, default=True)
    last_login    = db.Column(db.DateTime, nullable=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    tenant        = db.relationship("Tenant", back_populates="users")

    def set_password(self, pw):
        self.password_hash = bcrypt.generate_password_hash(pw).decode("utf-8")

    def check_password(self, pw):
        return bcrypt.check_password_hash(self.password_hash, pw)

    def can(self, action):
        perms = {
            "superadmin": ["view","create","update","delete","admin","superadmin"],
            "admin":      ["view","create","update","delete","admin"],
            "analyst":    ["view","create","update"],
            "viewer":     ["view"],
        }
        return action in perms.get(self.role, [])

    def __repr__(self):
        return f"<TenantUser {self.email} [{self.role}]>"


# ── Incident ───────────────────────────────────────────────────
class Incident(db.Model):
    __tablename__ = "incidents"
    id            = db.Column(db.Integer, primary_key=True)
    tenant_id     = db.Column(db.Integer, db.ForeignKey("tenants.id"), nullable=False, index=True)
    number        = db.Column(db.String(16), nullable=False, index=True)
    title         = db.Column(db.String(200), nullable=False)
    threat_type   = db.Column(db.String(60), nullable=False)
    severity      = db.Column(db.String(10), nullable=False)
    status        = db.Column(db.String(20), default="Open", index=True)
    confidence    = db.Column(db.Float, default=0.0)
    source_ip     = db.Column(db.String(45), nullable=True)
    dest_ip       = db.Column(db.String(45), nullable=True)
    port          = db.Column(db.String(10), nullable=True)
    protocol      = db.Column(db.String(10), nullable=True)
    raw_event     = db.Column(db.Text, nullable=True)
    source_type   = db.Column(db.String(30), default="network")  # network/syslog/winlog/manual
    agent_id      = db.Column(db.String(64), nullable=True)      # which agent sent this
    hostname      = db.Column(db.String(120), nullable=True)     # real hostname from agent
    model_used    = db.Column(db.String(40), default="AI")
    # ISO 27001
    iso_controls  = db.Column(db.Text, default="[]")
    iso_finding   = db.Column(db.Text, nullable=True)
    iso_actions   = db.Column(db.Text, default="[]")
    evidence      = db.Column(db.Text, default="[]")
    # Timestamps
    created_at    = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at    = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at   = db.Column(db.DateTime, nullable=True)
    tenant        = db.relationship("Tenant", back_populates="incidents")
    notes         = db.relationship("IncidentNote",     back_populates="incident", cascade="all, delete-orphan")
    timeline      = db.relationship("IncidentTimeline", back_populates="incident", cascade="all, delete-orphan", order_by="IncidentTimeline.time")

    def to_dict(self):
        return {
            "id":          self.number,
            "db_id":       self.id,
            "number":      self.number,
            "title":       self.title,
            "threat_type": self.threat_type,
            "severity":    self.severity,
            "status":      self.status,
            "confidence":  self.confidence,
            "source_ip":   self.source_ip or "",
            "dest_ip":     self.dest_ip   or "",
            "port":        self.port      or "",
            "protocol":    self.protocol  or "",
            "source_type": self.source_type,
            "hostname":    self.hostname  or "",
            "agent_id":    self.agent_id  or "",
            "raw_event":   self.raw_event or "",
            "model_used":  self.model_used,
            "iso_controls":json.loads(self.iso_controls or "[]"),
            "iso_finding": self.iso_finding or "",
            "iso_actions": json.loads(self.iso_actions or "[]"),
            "evidence":    json.loads(self.evidence or "[]"),
            "created_at":  self.created_at.isoformat()  if self.created_at  else "",
            "updated_at":  self.updated_at.isoformat()  if self.updated_at  else "",
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "notes":    [n.to_dict() for n in self.notes],
            "timeline": [t.to_dict() for t in self.timeline],
        }


class IncidentNote(db.Model):
    __tablename__ = "incident_notes"
    id          = db.Column(db.Integer, primary_key=True)
    incident_id = db.Column(db.Integer, db.ForeignKey("incidents.id"), nullable=False)
    text        = db.Column(db.Text, nullable=False)
    actor       = db.Column(db.String(64), default="Analyst")
    time        = db.Column(db.DateTime, default=datetime.utcnow)
    incident    = db.relationship("Incident", back_populates="notes")
    def to_dict(self):
        return {"text":self.text,"actor":self.actor,"time":self.time.isoformat() if self.time else ""}


class IncidentTimeline(db.Model):
    __tablename__ = "incident_timeline"
    id          = db.Column(db.Integer, primary_key=True)
    incident_id = db.Column(db.Integer, db.ForeignKey("incidents.id"), nullable=False)
    action      = db.Column(db.Text, nullable=False)
    actor       = db.Column(db.String(64), default="System")
    note        = db.Column(db.Text, nullable=True)
    time        = db.Column(db.DateTime, default=datetime.utcnow)
    incident    = db.relationship("Incident", back_populates="timeline")
    def to_dict(self):
        return {"action":self.action,"actor":self.actor,"note":self.note or "","time":self.time.isoformat() if self.time else ""}


# ── Audit Log ──────────────────────────────────────────────────
class AuditLog(db.Model):
    __tablename__ = "audit_logs"
    id         = db.Column(db.Integer, primary_key=True)
    tenant_id  = db.Column(db.Integer, db.ForeignKey("tenants.id"), nullable=False, index=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("tenant_users.id"), nullable=True)
    username   = db.Column(db.String(64), nullable=True)
    action     = db.Column(db.String(200), nullable=False)
    target     = db.Column(db.String(200), nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    timestamp  = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    tenant     = db.relationship("Tenant", back_populates="audit_logs")
    def to_dict(self):
        return {"username":self.username,"action":self.action,"target":self.target or "",
                "ip_address":self.ip_address or "","timestamp":self.timestamp.isoformat() if self.timestamp else ""}


# ── Agent Token (for real data ingestion) ─────────────────────
class AgentToken(db.Model):
    """
    Each client gets an agent token.
    Winlogbeat / syslog agents use this token to authenticate
    when sending real events to the platform API.
    """
    __tablename__ = "agent_tokens"
    id          = db.Column(db.Integer, primary_key=True)
    tenant_id   = db.Column(db.Integer, db.ForeignKey("tenants.id"), nullable=False)
    token       = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name        = db.Column(db.String(80), default="Default agent")
    description = db.Column(db.String(200), nullable=True)
    is_active   = db.Column(db.Boolean, default=True)
    last_seen   = db.Column(db.DateTime, nullable=True)
    event_count = db.Column(db.Integer, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    tenant      = db.relationship("Tenant", back_populates="agent_tokens")

    @staticmethod
    def generate():
        return secrets.token_hex(32)

    def to_dict(self):
        return {"id":self.id,"name":self.name,"token_preview":self.token[:8]+"...",
                "is_active":self.is_active,"event_count":self.event_count,
                "last_seen":self.last_seen.isoformat() if self.last_seen else None,
                "created_at":self.created_at.isoformat() if self.created_at else ""}


# ── Subscription Plan (local mirror of Stripe) ─────────────────
class Subscription(db.Model):
    __tablename__ = "subscriptions"
    id              = db.Column(db.Integer, primary_key=True)
    tenant_id       = db.Column(db.Integer, db.ForeignKey("tenants.id"), unique=True)
    plan            = db.Column(db.String(20), default="starter")
    status          = db.Column(db.String(20), default="trialing")
    stripe_sub_id   = db.Column(db.String(100), nullable=True)
    stripe_cust_id  = db.Column(db.String(100), nullable=True)
    amount_pence    = db.Column(db.Integer, default=0)
    currency        = db.Column(db.String(5), default="gbp")
    current_period_start = db.Column(db.DateTime, nullable=True)
    current_period_end   = db.Column(db.DateTime, nullable=True)
    created_at      = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at      = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {"plan":self.plan,"status":self.status,
                "amount":f"£{self.amount_pence/100:.2f}/mo",
                "period_end":self.current_period_end.isoformat() if self.current_period_end else None}


# ── Super Admin (platform owner — you) ───────────────────────
class SuperAdmin(UserMixin, db.Model):
    __tablename__ = "super_admins"
    id            = db.Column(db.Integer, primary_key=True)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, pw):
        self.password_hash = bcrypt.generate_password_hash(pw).decode("utf-8")

    def check_password(self, pw):
        return bcrypt.check_password_hash(self.password_hash, pw)

    def get_id(self):
        return f"superadmin:{self.id}"
