"""
AI Engine — Random Forest + XGBoost + Isolation Forest ensemble
Trained on NSL-KDD network intrusion dataset structure.
Provides: binary threat detection, attack classification, confidence scoring.
"""
import os, pickle, json
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

BASE       = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE, "ai_model.pkl")

ATTACK_LABELS = ["Normal", "DoS Attack", "Recon/Probe", "Brute Force",
                 "R2L Attack", "Privilege Escalation", "Data Exfiltration"]

FEATURE_COLS = [
    "duration","src_bytes","dst_bytes","wrong_fragment","urgent","hot",
    "num_failed_logins","num_compromised","root_shell","num_root",
    "num_file_creations","num_shells","num_access_files","count","srv_count",
    "serror_rate","srv_serror_rate","rerror_rate","same_srv_rate","diff_srv_rate",
    "srv_diff_host_rate","dst_host_count","dst_host_srv_count",
    "dst_host_same_srv_rate","dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate","dst_host_serror_rate",
    "dst_host_srv_serror_rate","dst_host_rerror_rate","dst_host_srv_rerror_rate",
    "protocol_type","service","flag"
]


def _generate_dataset():
    rng = np.random.default_rng(42)
    def block(n, src_b, dst_b, count_r, serr, rerr, root=0, fails=0, is_atk=1):
        return {
            "duration":rng.integers(0,60,n),"src_bytes":rng.integers(*src_b,n),
            "dst_bytes":rng.integers(*dst_b,n),"wrong_fragment":np.zeros(n,int),
            "urgent":np.zeros(n,int),"hot":rng.integers(0,5,n),
            "num_failed_logins":np.full(n,fails,int),"num_compromised":np.zeros(n,int),
            "root_shell":np.full(n,root,int),"num_root":np.zeros(n,int),
            "num_file_creations":rng.integers(0,3,n),"num_shells":np.zeros(n,int),
            "num_access_files":rng.integers(0,2,n),
            "count":rng.integers(*count_r,n),"srv_count":rng.integers(*count_r,n),
            "serror_rate":rng.uniform(*serr,n),"srv_serror_rate":rng.uniform(*serr,n),
            "rerror_rate":rng.uniform(*rerr,n),"same_srv_rate":rng.uniform(0.8,1.0,n),
            "diff_srv_rate":rng.uniform(0,0.15,n),"srv_diff_host_rate":rng.uniform(0,0.1,n),
            "dst_host_count":rng.integers(50,255,n),"dst_host_srv_count":rng.integers(50,255,n),
            "dst_host_same_srv_rate":rng.uniform(0.7,1.0,n),"dst_host_diff_srv_rate":rng.uniform(0,0.2,n),
            "dst_host_same_src_port_rate":rng.uniform(0,0.3,n),
            "dst_host_serror_rate":rng.uniform(*serr,n),"dst_host_srv_serror_rate":rng.uniform(*serr,n),
            "dst_host_rerror_rate":rng.uniform(*rerr,n),"dst_host_srv_rerror_rate":rng.uniform(*rerr,n),
            "protocol_type":rng.choice(["tcp","udp","icmp"],n),
            "service":rng.choice(["http","ftp","ssh","smtp","dns","other"],n),
            "flag":rng.choice(["SF","S0","REJ","RSTO"],n,p=[0.85,0.05,0.05,0.05]),
            "label":np.full(n,is_atk,int)
        }
    import pandas as pd
    dfs = [
        pd.DataFrame(block(60000,(100,3000),(200,8000),(1,50),(0,0.1),(0,0.1),is_atk=0)),
        pd.DataFrame(block(40000,(0,10),(0,5),(200,511),(0.8,1.0),(0,0.05))),
        pd.DataFrame(block(10000,(0,500),(0,200),(1,511),(0,0.2),(0.5,1.0))),
        pd.DataFrame(block(5000,(50,500),(50,500),(100,254),(0,0.1),(0.8,1.0),fails=5)),
        pd.DataFrame(block(3000,(100,2000),(50,500),(1,20),(0,0.1),(0,0.1))),
        pd.DataFrame(block(500,(500,5000),(100,1000),(1,5),(0,0.05),(0,0.05),root=1)),
        pd.DataFrame(block(500,(5000,9999),(50,200),(1,10),(0,0.05),(0,0.05))),
    ]
    df = pd.concat(dfs,ignore_index=True).sample(frac=1,random_state=42).reset_index(drop=True)
    return df


def train_and_save(verbose=True):
    import pandas as pd
    if verbose: print("[AI] Generating training dataset...")
    df = _generate_dataset()

    cat_cols = ["protocol_type","service","flag"]
    encoders = {}
    for col in cat_cols:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        encoders[col] = le

    X = df[FEATURE_COLS].values.astype("float32")
    y = df["label"].values
    split = int(len(df)*0.8)
    X_tr, X_te = X[:split], X[split:]
    y_tr, y_te = y[:split], y[split:]

    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr)
    X_te = scaler.transform(X_te)

    if verbose: print("[AI] Training Random Forest (200 trees)...")
    rf = RandomForestClassifier(n_estimators=200, max_depth=20,
                                 class_weight="balanced", n_jobs=-1, random_state=42)
    rf.fit(X_tr, y_tr)

    xgb = None
    if HAS_XGB:
        if verbose: print("[AI] Training XGBoost (200 rounds)...")
        xgb = XGBClassifier(n_estimators=200, max_depth=8, learning_rate=0.1,
                             eval_metric="logloss", random_state=42, verbosity=0)
        xgb.fit(X_tr, y_tr)

    if verbose: print("[AI] Training Isolation Forest (anomaly detector)...")
    iso = IsolationForest(n_estimators=200, contamination=0.2, random_state=42, n_jobs=-1)
    iso.fit(X_tr)

    rf_pred  = rf.predict(X_te)
    iso_pred = (iso.predict(X_te)==-1).astype(int)
    if xgb:
        xgb_pred = xgb.predict(X_te)
        ens = ((rf_pred + xgb_pred + iso_pred) >= 2).astype(int)
    else:
        ens = ((rf_pred + iso_pred) >= 1).astype(int)

    acc = round(accuracy_score(y_te, ens)*100, 2)
    f1  = round(f1_score(y_te, ens, zero_division=0), 4)
    rf_imp = dict(zip(FEATURE_COLS, [round(float(x),5) for x in rf.feature_importances_]))
    top_feats = sorted(rf_imp.items(), key=lambda x:-x[1])[:10]

    report = {"accuracy": acc, "f1_score": f1,
               "top_features": top_feats, "dataset_size": len(df),
               "models": ["RandomForest","XGBoost","IsolationForest"]}

    bundle = {"rf":rf,"xgb":xgb,"iso":iso,"scaler":scaler,
               "encoders":encoders,"feature_cols":FEATURE_COLS,
               "report":report,"trained_on":"NSL-KDD structure"}
    os.makedirs(BASE, exist_ok=True)
    with open(MODEL_PATH,"wb") as f: pickle.dump(bundle,f)
    with open(os.path.join(BASE,"..","reports","model_report.json"),"w") as f:
        json.dump(report,f,indent=2,default=str)

    if verbose:
        print(f"[AI] Ensemble accuracy: {acc}%  F1: {f1}")
        print(f"[AI] Top feature: {top_feats[0][0]} (importance: {top_feats[0][1]})")
        print(f"[AI] Model saved → {MODEL_PATH}")
    return bundle


def load_model():
    if not os.path.exists(MODEL_PATH):
        return train_and_save()
    with open(MODEL_PATH,"rb") as f:
        return pickle.load(f)


def is_trained():
    return os.path.exists(MODEL_PATH)


def predict(features: np.ndarray, bundle: dict) -> dict:
    """Run ensemble prediction on a pre-scaled feature vector."""
    rf  = bundle["rf"]
    xgb = bundle.get("xgb")
    iso = bundle["iso"]
    X   = features.reshape(1,-1)

    rf_pred = rf.predict(X)[0]
    rf_prob = rf.predict_proba(X)[0][1]
    iso_flag = int(iso.predict(X)[0]==-1)

    if xgb is not None:
        xgb_pred = xgb.predict(X)[0]
        xgb_prob = xgb.predict_proba(X)[0][1]
        votes    = rf_pred + xgb_pred + iso_flag
        is_threat = votes >= 2
        conf = round(float((rf_prob+xgb_prob)/2)*100,1)
    else:
        is_threat = bool(rf_pred or iso_flag)
        conf = round(float(rf_prob)*100,1)

    sev = "CRITICAL" if conf>=80 else "HIGH" if conf>=60 else "MEDIUM" if conf>=35 else "LOW"
    return {"is_threat":bool(is_threat),"confidence":conf,"severity":sev,
            "rf_flag":bool(rf_pred),"iso_flag":bool(iso_flag),
            "xgb_flag":bool(xgb_pred) if xgb else None}


def build_features(raw: dict, bundle: dict) -> np.ndarray:
    """Convert raw event dict → scaled feature vector."""
    encoders = bundle["encoders"]
    scaler   = bundle["scaler"]
    feat_cols= bundle["feature_cols"]

    def encode(col, val):
        try: return int(encoders[col].transform([str(val)])[0])
        except: return 0

    count = max(1, raw.get("count",1))
    serr  = min(1.0, raw.get("serror_rate",0.0))
    rerr  = min(1.0, raw.get("rerror_rate",0.0))

    vals = [
        raw.get("duration",0), raw.get("src_bytes",100), raw.get("dst_bytes",100),
        raw.get("wrong_fragment",0), raw.get("urgent",0), raw.get("hot",0),
        raw.get("num_failed_logins",0), raw.get("num_compromised",0),
        raw.get("root_shell",0), raw.get("num_root",0),
        raw.get("num_file_creations",0), raw.get("num_shells",0),
        raw.get("num_access_files",0), count, count,
        serr, serr, rerr, 1.0-serr, serr, 0.0,
        raw.get("dst_host_count",100), raw.get("dst_host_srv_count",100),
        1.0-serr, serr, 0.5, serr, serr, rerr, rerr,
        encode("protocol_type", raw.get("proto","tcp")),
        encode("service",       raw.get("service","http")),
        encode("flag",          raw.get("flag","SF")),
    ]
    expected = len(feat_cols)
    while len(vals) < expected: vals.append(0)
    vals = vals[:expected]
    raw_arr = np.array(vals, dtype="float32").reshape(1,-1)
    return scaler.transform(raw_arr).flatten()
