"""
ISO 27001:2022 Compliance Engine
Maps detected threats to specific ISO 27001 Annex A controls.
Generates compliance reports, tracks control gaps, scores posture.
"""
import json, os
from datetime import datetime

# ISO 27001:2022 Annex A controls relevant to SOC operations
ISO_CONTROLS = {
    "A.5.1":  {"name": "Policies for information security",      "domain": "Organisational"},
    "A.5.7":  {"name": "Threat intelligence",                    "domain": "Organisational"},
    "A.5.25": {"name": "Assessment and decision on information security events", "domain": "Organisational"},
    "A.5.26": {"name": "Response to information security incidents", "domain": "Organisational"},
    "A.5.28": {"name": "Collection of evidence",                 "domain": "Organisational"},
    "A.6.8":  {"name": "Information security event reporting",   "domain": "People"},
    "A.8.6":  {"name": "Capacity management",                    "domain": "Technological"},
    "A.8.7":  {"name": "Protection against malware",             "domain": "Technological"},
    "A.8.8":  {"name": "Management of technical vulnerabilities","domain": "Technological"},
    "A.8.15": {"name": "Logging",                                "domain": "Technological"},
    "A.8.16": {"name": "Monitoring activities",                  "domain": "Technological"},
    "A.8.20": {"name": "Networks security",                      "domain": "Technological"},
    "A.8.21": {"name": "Security of network services",           "domain": "Technological"},
    "A.8.22": {"name": "Segregation of networks",               "domain": "Technological"},
    "A.8.23": {"name": "Web filtering",                          "domain": "Technological"},
    "A.8.25": {"name": "Secure development life cycle",          "domain": "Technological"},
}

# Map threat types → triggered ISO 27001 controls + recommended actions
THREAT_CONTROL_MAP = {
    "Brute Force": {
        "controls":    ["A.8.7","A.8.16","A.5.26","A.8.15"],
        "risk_level":  "HIGH",
        "finding":     "Multiple failed authentication attempts detected — potential brute force attack.",
        "actions": [
            "Implement account lockout policy (≥5 failed attempts)",
            "Enable multi-factor authentication (MFA) on all accounts",
            "Review and update password complexity requirements",
            "Monitor and alert on authentication anomalies (A.8.16)",
            "Document incident per ISO 27001 A.5.26 response procedure",
        ],
        "evidence_required": ["Authentication logs","Account lockout events","IP geolocation data"],
    },
    "DoS Attack": {
        "controls":    ["A.8.6","A.8.20","A.8.16","A.5.26"],
        "risk_level":  "CRITICAL",
        "finding":     "Denial of Service attack detected — service availability threatened.",
        "actions": [
            "Activate DDoS mitigation controls immediately",
            "Block source IP ranges at perimeter firewall",
            "Engage ISP-level filtering if volumetric attack",
            "Review capacity and availability plan (A.8.6)",
            "Record incident with timestamps for evidence (A.5.28)",
        ],
        "evidence_required": ["Network flow logs","Firewall logs","Service availability metrics"],
    },
    "Recon / Probe": {
        "controls":    ["A.8.8","A.8.16","A.8.20","A.5.7"],
        "risk_level":  "MEDIUM",
        "finding":     "Reconnaissance activity detected — attacker mapping network/services.",
        "actions": [
            "Block scanning source IP at firewall",
            "Review exposed services and close unnecessary ports",
            "Run internal vulnerability scan to identify exposed weaknesses (A.8.8)",
            "Update threat intelligence feeds (A.5.7)",
            "Review network segmentation controls (A.8.22)",
        ],
        "evidence_required": ["Port scan logs","Firewall deny logs","Asset inventory"],
    },
    "Recon / Path Scanning": {
        "controls":    ["A.8.23","A.8.16","A.8.8","A.5.7"],
        "risk_level":  "MEDIUM",
        "finding":     "Web path scanning detected — attacker probing for vulnerable endpoints.",
        "actions": [
            "Enable Web Application Firewall (WAF) rules",
            "Block source IP and implement rate limiting",
            "Audit web application for exposed admin panels (A.8.23)",
            "Remove or protect sensitive paths (/.env, /wp-admin, etc.)",
            "Update vulnerability management register (A.8.8)",
        ],
        "evidence_required": ["Web server access logs","WAF alerts","Vulnerability scan results"],
    },
    "Data Exfiltration": {
        "controls":    ["A.8.20","A.8.22","A.5.26","A.5.28","A.8.15"],
        "risk_level":  "CRITICAL",
        "finding":     "Potential data exfiltration detected — large outbound data transfer to suspicious destination.",
        "actions": [
            "Immediately isolate affected system from network",
            "Block destination IP/domain at firewall and proxy",
            "Preserve logs and memory dumps as evidence (A.5.28)",
            "Initiate formal incident response procedure (A.5.26)",
            "Assess if GDPR/data breach notification is required",
            "Review DLP controls and egress filtering (A.8.20)",
        ],
        "evidence_required": ["Network flow data","Firewall logs","DLP alerts","System memory dump"],
    },
    "Metasploit C2": {
        "controls":    ["A.8.7","A.8.20","A.5.26","A.5.28"],
        "risk_level":  "CRITICAL",
        "finding":     "Command & Control (C2) communication detected — system may be compromised.",
        "actions": [
            "Immediately isolate the affected host",
            "Block C2 IP/domain at all network layers",
            "Perform full malware scan and forensic investigation",
            "Reset all credentials on affected system and connected accounts",
            "Initiate incident response and notify management (A.5.26)",
            "Preserve forensic evidence (A.5.28)",
        ],
        "evidence_required": ["Network capture (PCAP)","Process list","Registry exports","Memory dump"],
    },
    "SMB Exploit": {
        "controls":    ["A.8.8","A.8.20","A.8.7","A.5.26"],
        "risk_level":  "CRITICAL",
        "finding":     "SMB exploitation attempt detected — possible lateral movement or ransomware precursor.",
        "actions": [
            "Block SMB (port 445) at perimeter immediately",
            "Patch all systems for EternalBlue/SMB vulnerabilities",
            "Isolate affected network segment (A.8.22)",
            "Scan for ransomware indicators across all endpoints",
            "Review patch management process (A.8.8)",
        ],
        "evidence_required": ["SMB traffic logs","Patch status reports","EDR alerts"],
    },
    "Privilege Escalation": {
        "controls":    ["A.8.16","A.5.26","A.8.15","A.5.28"],
        "risk_level":  "CRITICAL",
        "finding":     "Privilege escalation attempt detected — attacker attempting to gain elevated access.",
        "actions": [
            "Lock affected user account immediately",
            "Review and audit privileged access rights",
            "Check for persistence mechanisms (scheduled tasks, registry)",
            "Enable enhanced logging on privileged accounts (A.8.15)",
            "Initiate incident response (A.5.26)",
        ],
        "evidence_required": ["Authentication logs","Sudo/event logs","Process creation logs"],
    },
    "Off-hours Auth Failure": {
        "controls":    ["A.8.16","A.6.8","A.5.25"],
        "risk_level":  "MEDIUM",
        "finding":     "Authentication failure outside business hours — possible insider threat or credential attack.",
        "actions": [
            "Investigate user account for compromise",
            "Review access logs for the account over past 30 days",
            "Verify with user if access attempt was legitimate",
            "Consider time-based access controls",
            "Document assessment per A.5.25",
        ],
        "evidence_required": ["Authentication logs","User activity timeline","HR records if insider threat suspected"],
    },
    "AI Anomaly Detected": {
        "controls":    ["A.8.16","A.5.7","A.5.25"],
        "risk_level":  "MEDIUM",
        "finding":     "AI model detected behavioural anomaly not matching known attack signatures — potential zero-day.",
        "actions": [
            "Manually investigate flagged traffic/activity",
            "Cross-reference with threat intelligence feeds (A.5.7)",
            "Escalate to Tier 2 analyst if anomaly cannot be explained",
            "Document findings and update detection rules",
            "Assess whether formal incident needs to be raised (A.5.25)",
        ],
        "evidence_required": ["Raw log entries","Network captures","AI model confidence scores"],
    },
    "Normal": {
        "controls":    [],
        "risk_level":  "LOW",
        "finding":     "No threat detected — traffic matches normal baseline.",
        "actions":     [],
        "evidence_required": [],
    },
}


def get_control_details(threat_type: str) -> dict:
    mapping = THREAT_CONTROL_MAP.get(threat_type, THREAT_CONTROL_MAP["AI Anomaly Detected"])
    controls = []
    for ctrl_id in mapping["controls"]:
        if ctrl_id in ISO_CONTROLS:
            controls.append({
                "id": ctrl_id,
                "name": ISO_CONTROLS[ctrl_id]["name"],
                "domain": ISO_CONTROLS[ctrl_id]["domain"],
            })
    return {
        "threat_type":       threat_type,
        "controls_triggered": controls,
        "risk_level":        mapping["risk_level"],
        "finding":           mapping["finding"],
        "recommended_actions": mapping["actions"],
        "evidence_required": mapping["evidence_required"],
        "iso_standard":      "ISO/IEC 27001:2022",
    }


def score_compliance(incidents: list) -> dict:
    """Score overall ISO 27001 compliance posture from incident history."""
    total     = len(incidents)
    resolved  = sum(1 for i in incidents if i.get("status") == "Resolved")
    critical  = sum(1 for i in incidents if i.get("severity") in ("CRITICAL","HIGH"))
    open_crit = sum(1 for i in incidents if i.get("severity") in ("CRITICAL","HIGH")
                    and i.get("status") != "Resolved")

    # Control coverage: which controls have been triggered
    triggered = set()
    for inc in incidents:
        tt = inc.get("threat_type","")
        mapping = THREAT_CONTROL_MAP.get(tt, {})
        for c in mapping.get("controls",[]):
            triggered.add(c)

    coverage = round(len(triggered)/len(ISO_CONTROLS)*100,1) if ISO_CONTROLS else 0

    # Posture score (0-100)
    if total == 0:
        posture = 85  # no incidents = baseline
    else:
        resolve_rate = resolved/total if total else 1
        open_penalty = min(50, open_crit*10)
        posture = max(0, round(resolve_rate*100 - open_penalty, 1))

    if posture >= 80:    rating = "GOOD"
    elif posture >= 60:  rating = "FAIR"
    elif posture >= 40:  rating = "POOR"
    else:                rating = "CRITICAL"

    # Gap analysis: which controls have never been tested/triggered
    untriggered = [{"id":k,"name":v["name"],"domain":v["domain"]}
                   for k,v in ISO_CONTROLS.items() if k not in triggered]

    return {
        "posture_score":      posture,
        "posture_rating":     rating,
        "total_incidents":    total,
        "resolved":           resolved,
        "open_critical":      open_crit,
        "controls_triggered": len(triggered),
        "controls_total":     len(ISO_CONTROLS),
        "coverage_pct":       coverage,
        "gap_analysis":       untriggered,
        "generated_at":       datetime.utcnow().isoformat(),
        "standard":           "ISO/IEC 27001:2022",
    }


def generate_compliance_report(incidents: list) -> dict:
    """Generate full ISO 27001 compliance report."""
    posture  = score_compliance(incidents)
    by_ctrl  = {}

    for inc in incidents:
        tt = inc.get("threat_type","")
        for ctrl in THREAT_CONTROL_MAP.get(tt,{}).get("controls",[]):
            if ctrl not in by_ctrl:
                by_ctrl[ctrl] = {"id":ctrl,"name":ISO_CONTROLS.get(ctrl,{}).get("name",""),
                                  "incidents":[],"status":"Active"}
            by_ctrl[ctrl]["incidents"].append(inc.get("id",""))

    return {
        "report_title":    "ISO 27001:2022 SOC Compliance Report",
        "organisation":    "Small/Medium Enterprise",
        "report_date":     datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        "standard":        "ISO/IEC 27001:2022 Annex A",
        "posture":         posture,
        "controls_detail": list(by_ctrl.values()),
        "summary": {
            "total_controls_in_scope": len(ISO_CONTROLS),
            "controls_triggered":      len(by_ctrl),
            "controls_not_triggered":  len(ISO_CONTROLS)-len(by_ctrl),
            "recommendation": (
                "Posture is strong — maintain current monitoring cadence."
                if posture["posture_score"] >= 80 else
                "Critical incidents unresolved — immediate remediation required."
                if posture["posture_score"] < 40 else
                "Review open incidents and implement recommended controls."
            ),
        },
    }
