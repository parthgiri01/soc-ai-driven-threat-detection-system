"""
PDF Report Generator — Phase 3
Generates professional ISO 27001:2022 compliance reports as downloadable PDFs.
Uses ReportLab for layout — no browser dependency needed.

Reports:
  - ISO 27001 compliance summary
  - Full incident report
  - Executive summary
"""

import os, json
from datetime import datetime
from io import BytesIO

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                     TableStyle, HRFlowable, PageBreak, KeepTogether)
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

# Brand colours
C_DARK    = colors.HexColor("#0d1117")
C_SURFACE = colors.HexColor("#161b22")
C_BORDER  = colors.HexColor("#30363d")
C_BLUE    = colors.HexColor("#58a6ff")
C_GREEN   = colors.HexColor("#3fb950")
C_YELLOW  = colors.HexColor("#d29922")
C_RED     = colors.HexColor("#f85149")
C_PURPLE  = colors.HexColor("#bc8cff")
C_TEXT    = colors.HexColor("#c9d1d9")
C_MUTED   = colors.HexColor("#8b949e")
C_WHITE   = colors.white

SEV_COLORS = {
    "CRITICAL": C_RED, "HIGH": C_YELLOW,
    "MEDIUM":   C_BLUE, "LOW": C_GREEN,
}
STATUS_COLORS = {
    "Open":          C_YELLOW,
    "Investigating": C_BLUE,
    "Resolved":      C_GREEN,
}


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("title", parent=base["Normal"],
                                 fontSize=22, textColor=C_BLUE, spaceAfter=6,
                                 fontName="Helvetica-Bold"),
        "subtitle": ParagraphStyle("subtitle", parent=base["Normal"],
                                    fontSize=12, textColor=C_MUTED, spaceAfter=20,
                                    fontName="Helvetica"),
        "h1": ParagraphStyle("h1", parent=base["Normal"],
                              fontSize=14, textColor=C_TEXT, spaceBefore=16, spaceAfter=8,
                              fontName="Helvetica-Bold"),
        "h2": ParagraphStyle("h2", parent=base["Normal"],
                              fontSize=11, textColor=C_BLUE, spaceBefore=12, spaceAfter=6,
                              fontName="Helvetica-Bold"),
        "body": ParagraphStyle("body", parent=base["Normal"],
                                fontSize=9, textColor=C_TEXT, spaceAfter=6,
                                fontName="Helvetica", leading=14),
        "muted": ParagraphStyle("muted", parent=base["Normal"],
                                 fontSize=8, textColor=C_MUTED, spaceAfter=4,
                                 fontName="Helvetica"),
        "code": ParagraphStyle("code", parent=base["Normal"],
                                fontSize=8, textColor=C_BLUE, spaceAfter=4,
                                fontName="Courier"),
    }


def _header_footer(canvas, doc, title="SOC Compliance Report"):
    """Draw header and footer on every page."""
    canvas.saveState()
    w, h = A4

    # Header bar
    canvas.setFillColor(C_SURFACE)
    canvas.rect(0, h-50, w, 50, fill=1, stroke=0)
    canvas.setFillColor(C_BLUE)
    canvas.rect(0, h-52, w, 2, fill=1, stroke=0)
    canvas.setFillColor(C_BLUE)
    canvas.setFont("Helvetica-Bold", 11)
    canvas.drawString(2*cm, h-32, "SOC Automation Platform")
    canvas.setFillColor(C_MUTED)
    canvas.setFont("Helvetica", 9)
    canvas.drawString(2*cm, h-44, f"ISO 27001:2022 — {title}")
    canvas.setFillColor(C_MUTED)
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(w-2*cm, h-36, datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"))

    # Footer
    canvas.setFillColor(C_SURFACE)
    canvas.rect(0, 0, w, 30, fill=1, stroke=0)
    canvas.setFillColor(C_BLUE)
    canvas.rect(0, 30, w, 1, fill=1, stroke=0)
    canvas.setFillColor(C_MUTED)
    canvas.setFont("Helvetica", 8)
    canvas.drawString(2*cm, 11, "CONFIDENTIAL — For authorised personnel only")
    canvas.drawRightString(w-2*cm, 11, f"Page {doc.page}")
    canvas.restoreState()


def _score_bar_table(score, rating):
    """Visual score bar as a table row."""
    col = (C_GREEN if score >= 80 else C_YELLOW if score >= 60
           else colors.HexColor("#f0883e") if score >= 40 else C_RED)
    filled = int(score / 5)
    empty  = 20 - filled
    bar    = ("█" * filled) + ("░" * empty)
    return Table(
        [[Paragraph(f"<font color='#{col.hexval()[2:]}'>{'▐' + bar + '▌'}</font>",
                     ParagraphStyle("bar", fontSize=10, fontName="Courier",
                                    textColor=col)),
          Paragraph(f"<b>{score}%</b>",
                     ParagraphStyle("sc", fontSize=14, fontName="Helvetica-Bold",
                                    textColor=col, alignment=TA_CENTER)),
          Paragraph(rating,
                     ParagraphStyle("rt", fontSize=11, fontName="Helvetica-Bold",
                                    textColor=col, alignment=TA_RIGHT))]],
        colWidths=[10*cm, 3*cm, 3*cm],
        style=TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), C_SURFACE),
            ("ROWBACKGROUNDS", (0,0), (-1,-1), [C_SURFACE]),
            ("BOX", (0,0), (-1,-1), 0.5, C_BORDER),
            ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
            ("TOPPADDING", (0,0), (-1,-1), 10),
            ("BOTTOMPADDING", (0,0), (-1,-1), 10),
            ("LEFTPADDING", (0,0), (-1,-1), 12),
        ])
    )


def _incident_table(incidents: list, styles: dict) -> Table:
    header = ["ID", "Threat Type", "Severity", "Status", "Source IP",
              "AI Conf.", "Created"]
    rows   = [header]
    for inc in incidents[:50]:
        sev    = inc.get("severity","")
        status = inc.get("status","")
        rows.append([
            inc.get("number",""),
            inc.get("threat_type","")[:25],
            sev,
            status,
            inc.get("source_ip","")[:16],
            f"{inc.get('confidence',0):.0f}%",
            (inc.get("created_at","") or "")[:10],
        ])

    sev_bg = {"CRITICAL":colors.HexColor("#490202"),"HIGH":colors.HexColor("#3d2b00"),
               "MEDIUM":colors.HexColor("#1c2d3f"),"LOW":colors.HexColor("#1a2f1a")}
    sev_fg = {"CRITICAL":C_RED,"HIGH":C_YELLOW,"MEDIUM":C_BLUE,"LOW":C_GREEN}

    col_widths = [2*cm, 4.5*cm, 2*cm, 2.5*cm, 2.5*cm, 1.5*cm, 2*cm]
    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND",   (0,0), (-1,0),  C_SURFACE),
        ("TEXTCOLOR",    (0,0), (-1,0),  C_MUTED),
        ("FONTNAME",     (0,0), (-1,0),  "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 8),
        ("FONTNAME",     (0,1), (-1,-1), "Helvetica"),
        ("TEXTCOLOR",    (0,1), (-1,-1), C_TEXT),
        ("GRID",         (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [C_DARK, C_SURFACE]),
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("TOPPADDING",   (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0), (-1,-1), 5),
        ("LEFTPADDING",  (0,0), (-1,-1), 6),
    ]
    for i, row in enumerate(rows[1:], 1):
        sev = row[2]
        if sev in sev_bg:
            style.append(("BACKGROUND", (2,i), (2,i), sev_bg[sev]))
            style.append(("TEXTCOLOR",  (2,i), (2,i), sev_fg[sev]))
    tbl.setStyle(TableStyle(style))
    return tbl


def _controls_table(controls: list) -> Table:
    header = ["Control ID", "Name", "Domain", "Status"]
    rows   = [header]
    triggered = {c.get("id") for c in controls}
    from models.iso27001 import ISO_CONTROLS
    for cid, cdata in ISO_CONTROLS.items():
        status = "Triggered" if cid in triggered else "Not triggered"
        rows.append([cid, cdata["name"][:40], cdata["domain"], status])

    tbl = Table(rows, colWidths=[2*cm, 7*cm, 3.5*cm, 2.5*cm], repeatRows=1)
    style = [
        ("BACKGROUND",    (0,0), (-1,0),  C_SURFACE),
        ("TEXTCOLOR",     (0,0), (-1,0),  C_MUTED),
        ("FONTNAME",      (0,0), (-1,0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("FONTNAME",      (0,1), (-1,-1), "Helvetica"),
        ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
        ("GRID",          (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),  [C_DARK, C_SURFACE]),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
    ]
    for i, row in enumerate(rows[1:], 1):
        if row[3] == "Triggered":
            style.append(("TEXTCOLOR", (3,i), (3,i), C_GREEN))
        else:
            style.append(("TEXTCOLOR", (3,i), (3,i), C_MUTED))
    tbl.setStyle(TableStyle(style))
    return tbl


# ── Public API ────────────────────────────────────────────────

def generate_compliance_pdf(incidents: list, compliance: dict) -> bytes:
    """
    Generate full ISO 27001:2022 compliance PDF report.
    Returns PDF bytes.
    """
    if not REPORTLAB_AVAILABLE:
        raise ImportError("ReportLab not installed. Run: pip install reportlab")

    buf    = BytesIO()
    s      = _styles()
    posture = compliance.get("posture", compliance)
    score   = posture.get("posture_score", 0)
    rating  = posture.get("posture_rating", "UNKNOWN")
    inc_stats = {
        "total":    len(incidents),
        "open":     sum(1 for i in incidents if i.get("status")=="Open"),
        "resolved": sum(1 for i in incidents if i.get("status")=="Resolved"),
        "critical": sum(1 for i in incidents if i.get("severity")=="CRITICAL"),
        "high":     sum(1 for i in incidents if i.get("severity")=="HIGH"),
    }

    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        topMargin=60, bottomMargin=40,
        leftMargin=2*cm, rightMargin=2*cm,
        title="ISO 27001:2022 SOC Compliance Report",
        author="SOC Automation Platform",
    )

    story = []

    # ── Cover section ─────────────────────────────────────────
    story += [
        Spacer(1, 0.5*cm),
        Paragraph("ISO 27001:2022 Compliance Report", s["title"]),
        Paragraph(f"Generated {datetime.utcnow().strftime('%d %B %Y, %H:%M UTC')} — SOC Automation Platform", s["subtitle"]),
        HRFlowable(width="100%", thickness=1, color=C_BORDER, spaceAfter=16),
    ]

    # ── Posture score ─────────────────────────────────────────
    story += [
        Paragraph("Security posture", s["h1"]),
        _score_bar_table(score, rating),
        Spacer(1, 0.4*cm),
    ]

    # ── Stats table ───────────────────────────────────────────
    stats_data = [
        ["Total incidents", "Open", "Resolved", "Critical", "High",
         "Controls triggered", "Coverage"],
        [str(inc_stats["total"]), str(inc_stats["open"]),
         str(inc_stats["resolved"]), str(inc_stats["critical"]),
         str(inc_stats["high"]),
         str(posture.get("controls_triggered",0)),
         f"{posture.get('coverage_pct',0)}%"],
    ]
    stats_tbl = Table(stats_data, colWidths=[2.3*cm]*7)
    stats_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0),  C_SURFACE),
        ("BACKGROUND",    (0,1), (-1,1),  C_DARK),
        ("TEXTCOLOR",     (0,0), (-1,0),  C_MUTED),
        ("TEXTCOLOR",     (0,1), (-1,1),  C_TEXT),
        ("FONTNAME",      (0,0), (-1,0),  "Helvetica-Bold"),
        ("FONTNAME",      (0,1), (-1,1),  "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 9),
        ("ALIGN",         (0,0), (-1,-1), "CENTER"),
        ("GRID",          (0,0), (-1,-1), 0.3, C_BORDER),
        ("TOPPADDING",    (0,0), (-1,-1), 7),
        ("BOTTOMPADDING", (0,0), (-1,-1), 7),
    ]))
    story += [stats_tbl, Spacer(1, 0.5*cm)]

    # ── Summary recommendation ────────────────────────────────
    rec = compliance.get("summary",{}).get("recommendation","")
    if not rec:
        rec = ("Posture is strong — maintain current monitoring cadence."
               if score >= 80 else
               "Critical incidents remain unresolved — immediate action required."
               if score < 40 else
               "Review open incidents and implement recommended ISO 27001 controls.")
    story += [
        Paragraph("Recommendation", s["h2"]),
        Paragraph(rec, s["body"]),
        Spacer(1, 0.3*cm),
    ]

    # ── ISO 27001 controls ────────────────────────────────────
    story += [
        HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=8),
        Paragraph("ISO 27001:2022 Annex A — Control status", s["h1"]),
        Paragraph("Controls triggered by detected incidents are marked 'Triggered'. "
                   "All others represent potential gaps for review.", s["muted"]),
        Spacer(1, 0.3*cm),
    ]
    controls_triggered = []
    for inc in incidents:
        ctrl_data = inc.get("iso_controls",[])
        if isinstance(ctrl_data, str):
            try: ctrl_data = json.loads(ctrl_data)
            except: ctrl_data = []
        controls_triggered.extend(ctrl_data)

    story += [_controls_table(controls_triggered), Spacer(1, 0.5*cm)]

    # ── Incidents ─────────────────────────────────────────────
    story += [
        PageBreak(),
        Paragraph("Incident register", s["h1"]),
        Paragraph(f"Showing {min(50,len(incidents))} of {len(incidents)} total incidents. "
                   "Sorted by creation date (newest first).", s["muted"]),
        Spacer(1, 0.3*cm),
        _incident_table(incidents, s),
        Spacer(1, 0.5*cm),
    ]

    # ── Gap analysis ──────────────────────────────────────────
    gaps = posture.get("gap_analysis",[])
    if gaps:
        story += [
            HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=8),
            Paragraph("Control gap analysis", s["h1"]),
            Paragraph("The following ISO 27001:2022 controls have not been triggered by any incident. "
                       "Review these proactively as part of your audit programme.", s["muted"]),
            Spacer(1, 0.3*cm),
        ]
        gap_rows = [["Control ID","Name","Domain"]]
        for g in gaps:
            gap_rows.append([g.get("id",""), g.get("name","")[:45], g.get("domain","")])
        gap_tbl = Table(gap_rows, colWidths=[2*cm, 8.5*cm, 4.5*cm], repeatRows=1)
        gap_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
            ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
            ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0), (-1,-1), 8),
            ("FONTNAME",      (0,1), (-1,-1), "Helvetica"),
            ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
            ("GRID",          (0,0), (-1,-1), 0.3, C_BORDER),
            ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_DARK, C_SURFACE]),
            ("TOPPADDING",    (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
            ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ]))
        story.append(gap_tbl)

    # ── Footer disclaimer ─────────────────────────────────────
    story += [
        Spacer(1, 1*cm),
        HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=8),
        Paragraph("This report was automatically generated by the SOC Automation Platform. "
                   "It is aligned with ISO/IEC 27001:2022 Annex A control requirements. "
                   "For audit purposes, retain this report for a minimum of 3 years "
                   "in accordance with ISO 27001 clause 7.5 (documented information).",
                   s["muted"]),
    ]

    doc.build(story,
              onFirstPage=lambda c,d: _header_footer(c, d, "ISO 27001:2022 Compliance Report"),
              onLaterPages=lambda c,d: _header_footer(c, d, "ISO 27001:2022 Compliance Report"))

    return buf.getvalue()


def generate_incident_pdf(incident: dict) -> bytes:
    """Generate a single-incident PDF report."""
    if not REPORTLAB_AVAILABLE:
        raise ImportError("ReportLab not installed.")

    buf = BytesIO()
    s   = _styles()
    sev = incident.get("severity","HIGH")

    doc = SimpleDocTemplate(buf, pagesize=A4,
                             topMargin=60, bottomMargin=40,
                             leftMargin=2*cm, rightMargin=2*cm)
    story = []

    story += [
        Spacer(1, 0.5*cm),
        Paragraph(f"Incident Report — {incident.get('number','')}", s["title"]),
        Paragraph(incident.get("title",""), s["subtitle"]),
        HRFlowable(width="100%", thickness=1, color=C_BORDER, spaceAfter=12),
    ]

    # Details table
    sev_col = SEV_COLORS.get(sev, C_TEXT)
    details = [
        ["Field", "Value"],
        ["Incident ID",    incident.get("number","")],
        ["Threat type",    incident.get("threat_type","")],
        ["Severity",       sev],
        ["Status",         incident.get("status","")],
        ["Source IP",      incident.get("source_ip","")],
        ["AI confidence",  f"{incident.get('confidence',0):.0f}%"],
        ["Model",          incident.get("model_used","AI")],
        ["Created",        (incident.get("created_at","") or "")[:19].replace("T"," ") + " UTC"],
        ["Resolved",       (incident.get("resolved_at","") or "Not resolved")[:19].replace("T"," ")],
    ]
    det_tbl = Table(details, colWidths=[4*cm, 12*cm])
    det_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
        ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
        ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 9),
        ("FONTNAME",      (0,1), (-1,-1), "Helvetica"),
        ("TEXTCOLOR",     (0,1), (0,-1), C_MUTED),
        ("TEXTCOLOR",     (1,1), (1,-1), C_TEXT),
        ("GRID",          (0,0), (-1,-1), 0.3, C_BORDER),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_DARK, C_SURFACE]),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
    ]))
    story += [det_tbl, Spacer(1, 0.5*cm)]

    # ISO finding
    story += [
        Paragraph("ISO 27001:2022 Finding", s["h2"]),
        Paragraph(incident.get("iso_finding",""), s["body"]),
        Spacer(1, 0.3*cm),
    ]

    # Controls
    ctrl_data = incident.get("iso_controls",[])
    if isinstance(ctrl_data, str):
        try: ctrl_data = json.loads(ctrl_data)
        except: ctrl_data = []
    if ctrl_data:
        story.append(Paragraph("Controls triggered", s["h2"]))
        for c in ctrl_data:
            story.append(Paragraph(
                f"<font color='#58a6ff'><b>{c.get('id','')}</b></font> — "
                f"{c.get('name','')} ({c.get('domain','')})", s["body"]))
        story.append(Spacer(1, 0.3*cm))

    # Actions
    actions = incident.get("iso_actions",[])
    if isinstance(actions, str):
        try: actions = json.loads(actions)
        except: actions = []
    if actions:
        story.append(Paragraph("Recommended actions", s["h2"]))
        for i, a in enumerate(actions, 1):
            story.append(Paragraph(f"{i}. {a}", s["body"]))
        story.append(Spacer(1, 0.3*cm))

    # Evidence
    evidence = incident.get("evidence",[])
    if isinstance(evidence, str):
        try: evidence = json.loads(evidence)
        except: evidence = []
    if evidence:
        story.append(Paragraph("Evidence required", s["h2"]))
        for e in evidence:
            story.append(Paragraph(f"• {e}", s["body"]))
        story.append(Spacer(1, 0.3*cm))

    # Timeline
    timeline = incident.get("timeline",[])
    if timeline:
        story.append(Paragraph("Incident timeline", s["h2"]))
        tl_rows = [["Time (UTC)","Action","Actor"]]
        for t in timeline:
            tl_rows.append([
                (t.get("time","") or "")[:19].replace("T"," "),
                t.get("action","")[:60],
                t.get("actor","System"),
            ])
        tl_tbl = Table(tl_rows, colWidths=[4*cm, 10*cm, 3*cm], repeatRows=1)
        tl_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0), C_SURFACE),
            ("TEXTCOLOR",     (0,0), (-1,0), C_MUTED),
            ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0), (-1,-1), 8),
            ("FONTNAME",      (0,1), (-1,-1), "Helvetica"),
            ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
            ("GRID",          (0,0), (-1,-1), 0.3, C_BORDER),
            ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_DARK, C_SURFACE]),
            ("TOPPADDING",    (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
            ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ]))
        story.append(tl_tbl)

    doc.build(story,
              onFirstPage=lambda c,d: _header_footer(c, d, f"Incident {incident.get('number','')}"),
              onLaterPages=lambda c,d: _header_footer(c, d, f"Incident {incident.get('number','')}"))
    return buf.getvalue()


def is_available() -> bool:
    return REPORTLAB_AVAILABLE
