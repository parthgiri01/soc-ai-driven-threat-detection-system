"""
SIEM Integration — Phase 4
Bidirectional integration with Splunk and Microsoft Sentinel.

Splunk:   Push alerts via HEC (HTTP Event Collector)
          Pull search results via REST API
Sentinel: Push via Data Collector API
          Pull alerts via Log Analytics REST API
"""

import os, json, requests, hashlib, hmac, base64, time
from datetime import datetime, timezone
from urllib.parse import urlencode


# ── Splunk HEC Integration ────────────────────────────────────

class SplunkIntegration:
    """
    Splunk HTTP Event Collector integration.
    Pushes SOC incidents and alerts to Splunk index.
    """

    def __init__(self):
        self.hec_url   = os.getenv("SPLUNK_HEC_URL", "")    # e.g. https://splunk:8088
        self.hec_token = os.getenv("SPLUNK_HEC_TOKEN", "")  # HEC token from Splunk
        self.index     = os.getenv("SPLUNK_INDEX", "soc_platform")
        self.verify_ssl= os.getenv("SPLUNK_VERIFY_SSL", "true").lower() == "true"

    @property
    def configured(self) -> bool:
        return bool(self.hec_url and self.hec_token)

    def push_incident(self, incident: dict) -> dict:
        """Push a single incident to Splunk via HEC."""
        if not self.configured:
            return {"status": "skipped", "reason": "Splunk HEC not configured in .env"}

        event = {
            "time":       self._parse_ts(incident.get("created_at","")),
            "host":       incident.get("source_ip", "unknown"),
            "source":     "soc_automation_platform",
            "sourcetype": "soc:incident",
            "index":      self.index,
            "event": {
                "incident_id":  incident.get("number",""),
                "title":        incident.get("title",""),
                "threat_type":  incident.get("threat_type",""),
                "severity":     incident.get("severity",""),
                "status":       incident.get("status",""),
                "confidence":   incident.get("confidence",0),
                "source_ip":    incident.get("source_ip",""),
                "iso_controls": [c.get("id") for c in incident.get("iso_controls",[])],
                "iso_finding":  incident.get("iso_finding",""),
                "model":        incident.get("model_used","AI"),
                "platform":     "SOC Automation Platform",
            },
        }
        return self._hec_post(event)

    def push_alert(self, alert: dict) -> dict:
        """Push a raw network/log alert to Splunk."""
        if not self.configured:
            return {"status": "skipped", "reason": "not configured"}

        event = {
            "time":       time.time(),
            "host":       alert.get("src_ip", alert.get("ip", "unknown")),
            "source":     "soc_automation_platform",
            "sourcetype": "soc:alert",
            "index":      self.index,
            "event": {
                "threat_type": alert.get("threat_type",""),
                "severity":    alert.get("severity",""),
                "is_threat":   alert.get("is_threat", False),
                "confidence":  alert.get("confidence", 0),
                "src_ip":      alert.get("src_ip",""),
                "dst_ip":      alert.get("dst_ip",""),
                "protocol":    alert.get("proto",""),
                "port":        alert.get("dport",""),
                "model":       alert.get("model","AI"),
            },
        }
        return self._hec_post(event)

    def push_batch(self, events: list) -> dict:
        """Push multiple events to Splunk in one request."""
        if not self.configured:
            return {"status": "skipped", "reason": "not configured"}
        if not events:
            return {"status": "skipped", "reason": "no events"}

        # Splunk HEC accepts newline-delimited JSON for batch
        batch = "\n".join(json.dumps({
            "time":       time.time(),
            "host":       e.get("src_ip","unknown"),
            "source":     "soc_automation_platform",
            "sourcetype": "soc:event",
            "index":      self.index,
            "event":      e,
        }) for e in events)

        return self._hec_post_raw(batch)

    def search(self, query: str, earliest: str = "-24h", latest: str = "now") -> dict:
        """Run a Splunk search and return results."""
        api_url = os.getenv("SPLUNK_API_URL", self.hec_url.replace(":8088","") + ":8089")
        user    = os.getenv("SPLUNK_USER","admin")
        pw      = os.getenv("SPLUNK_PASS","")

        if not (api_url and user and pw):
            return {"status": "error", "reason": "Splunk API credentials not configured"}

        try:
            search_url = f"{api_url}/services/search/jobs"
            r = requests.post(search_url, auth=(user, pw),
                               data={"search": f"search {query}",
                                     "earliest_time": earliest,
                                     "latest_time": latest,
                                     "output_mode": "json"},
                               verify=self.verify_ssl, timeout=30)
            r.raise_for_status()
            sid = r.json().get("sid","")
            if not sid:
                return {"status": "error", "reason": "No search ID returned"}

            # Poll for results
            for _ in range(30):
                time.sleep(1)
                status_r = requests.get(
                    f"{api_url}/services/search/jobs/{sid}",
                    auth=(user, pw), params={"output_mode":"json"},
                    verify=self.verify_ssl, timeout=10)
                if status_r.json().get("entry",[{}])[0].get(
                        "content",{}).get("dispatchState") == "DONE":
                    break

            results_r = requests.get(
                f"{api_url}/services/search/jobs/{sid}/results",
                auth=(user, pw), params={"output_mode":"json","count":100},
                verify=self.verify_ssl, timeout=15)
            return {"status":"ok","results":results_r.json().get("results",[])}
        except Exception as e:
            return {"status": "error", "reason": str(e)}

    def _hec_post(self, event: dict) -> dict:
        return self._hec_post_raw(json.dumps(event))

    def _hec_post_raw(self, body: str) -> dict:
        try:
            r = requests.post(
                f"{self.hec_url}/services/collector/event",
                headers={"Authorization": f"Splunk {self.hec_token}",
                         "Content-Type": "application/json"},
                data=body, verify=self.verify_ssl, timeout=10)
            r.raise_for_status()
            return {"status":"ok","response":r.json()}
        except Exception as e:
            return {"status":"error","reason":str(e)}

    def _parse_ts(self, ts_str: str) -> float:
        try:
            return datetime.fromisoformat(ts_str.replace("Z","")).timestamp()
        except Exception:
            return time.time()

    def test_connection(self) -> dict:
        if not self.configured:
            return {"status": "not_configured",
                    "message": "Set SPLUNK_HEC_URL and SPLUNK_HEC_TOKEN in .env"}
        return self.push_incident({
            "number":"TEST-0001","title":"Connection test","threat_type":"Test",
            "severity":"LOW","status":"Open","confidence":0.0,
            "source_ip":"127.0.0.1","iso_controls":[],"iso_finding":"Test",
            "iso_actions":[],"model_used":"Test","created_at":datetime.utcnow().isoformat(),
        })


# ── Microsoft Sentinel Integration ───────────────────────────

class SentinelIntegration:
    """
    Microsoft Sentinel (Log Analytics) integration.
    Pushes SOC events to custom Log Analytics workspace table.
    """

    def __init__(self):
        self.workspace_id  = os.getenv("SENTINEL_WORKSPACE_ID","")
        self.shared_key    = os.getenv("SENTINEL_SHARED_KEY","")
        self.log_type      = os.getenv("SENTINEL_LOG_TYPE","SOCPlatformAlerts")

    @property
    def configured(self) -> bool:
        return bool(self.workspace_id and self.shared_key)

    def _build_signature(self, date: str, content_length: int,
                          content_type: str, resource: str) -> str:
        x_headers    = f"x-ms-date:{date}"
        string_to_hash = f"POST\n{content_length}\n{content_type}\n{x_headers}\n{resource}"
        bytes_to_hash  = string_to_hash.encode("utf-8")
        decoded_key    = base64.b64decode(self.shared_key)
        encoded_hash   = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode("utf-8")
        return f"SharedKey {self.workspace_id}:{encoded_hash}"

    def push_incident(self, incident: dict) -> dict:
        if not self.configured:
            return {"status":"skipped","reason":"Sentinel not configured in .env"}

        body = json.dumps([{
            "IncidentId":     incident.get("number",""),
            "Title":          incident.get("title",""),
            "ThreatType":     incident.get("threat_type",""),
            "Severity":       incident.get("severity",""),
            "Status":         incident.get("status",""),
            "Confidence":     incident.get("confidence",0),
            "SourceIP":       incident.get("source_ip",""),
            "ISOControls":    ",".join(c.get("id","") for c in incident.get("iso_controls",[])),
            "ISOFinding":     incident.get("iso_finding",""),
            "ModelUsed":      incident.get("model_used","AI"),
            "Platform":       "SOCAutomationPlatform",
            "TimeGenerated":  datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z"),
        }])

        return self._post(body)

    def push_alert(self, alert: dict) -> dict:
        if not self.configured:
            return {"status":"skipped","reason":"not configured"}

        body = json.dumps([{
            "ThreatType":    alert.get("threat_type",""),
            "Severity":      alert.get("severity",""),
            "IsThreat":      alert.get("is_threat",False),
            "Confidence":    alert.get("confidence",0),
            "SourceIP":      alert.get("src_ip",""),
            "DestinationIP": alert.get("dst_ip",""),
            "Protocol":      alert.get("proto",""),
            "Port":          str(alert.get("dport","")),
            "Platform":      "SOCAutomationPlatform",
            "TimeGenerated": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z"),
        }])
        return self._post(body)

    def _post(self, body: str) -> dict:
        resource      = "/api/logs"
        content_type  = "application/json"
        date          = datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length= len(body)
        signature     = self._build_signature(date, content_length, content_type, resource)
        url           = (f"https://{self.workspace_id}.ods.opinsights.azure.com"
                         f"{resource}?api-version=2016-04-01")
        try:
            r = requests.post(url, data=body, headers={
                "Content-Type":  content_type,
                "Authorization": signature,
                "Log-Type":      self.log_type,
                "x-ms-date":     date,
            }, timeout=15)
            if r.status_code == 200:
                return {"status":"ok"}
            return {"status":"error","code":r.status_code,"reason":r.text[:200]}
        except Exception as e:
            return {"status":"error","reason":str(e)}

    def test_connection(self) -> dict:
        if not self.configured:
            return {"status":"not_configured",
                    "message":"Set SENTINEL_WORKSPACE_ID and SENTINEL_SHARED_KEY in .env"}
        return self.push_incident({
            "number":"TEST-0001","title":"Connection test","threat_type":"Test",
            "severity":"LOW","status":"Open","confidence":0.0,"source_ip":"127.0.0.1",
            "iso_controls":[],"iso_finding":"Test","iso_actions":[],
            "model_used":"Test","created_at":datetime.utcnow().isoformat(),
        })


# ── Singleton instances ───────────────────────────────────────
splunk   = SplunkIntegration()
sentinel = SentinelIntegration()


def get_siem_status() -> dict:
    return {
        "splunk": {
            "configured": splunk.configured,
            "hec_url":    os.getenv("SPLUNK_HEC_URL","Not set"),
            "index":      splunk.index,
        },
        "sentinel": {
            "configured":    sentinel.configured,
            "workspace_id":  os.getenv("SENTINEL_WORKSPACE_ID","Not set"),
            "log_type":      sentinel.log_type,
        },
    }


def push_to_all_siems(incident: dict) -> dict:
    """Push incident to all configured SIEMs simultaneously."""
    import threading
    results = {}

    def _push(fn, name):
        results[name] = fn(incident)

    threads = [
        threading.Thread(target=_push, args=(splunk.push_incident,   "splunk"),   daemon=True),
        threading.Thread(target=_push, args=(sentinel.push_incident, "sentinel"), daemon=True),
    ]
    for t in threads: t.start()
    for t in threads: t.join(timeout=20)
    return results
