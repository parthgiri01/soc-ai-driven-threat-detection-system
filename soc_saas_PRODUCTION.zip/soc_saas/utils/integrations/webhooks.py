"""
Slack & Microsoft Teams Webhook Integration — Phase 4
Sends real-time alerts to enterprise communication channels.

Slack:   Create Incoming Webhook at api.slack.com/apps
Teams:   Create Incoming Webhook connector in Teams channel
Both:    Add webhook URL to .env
"""

import os, json, requests, threading, time
from datetime import datetime
from collections import deque

_alert_history = deque(maxlen=200)
_history_lock  = threading.Lock()
RATE_LIMIT_SEC = 120   # same incident won't re-alert within 2 mins
_sent_cache    = {}

SEV_EMOJI  = {"CRITICAL": "🚨", "HIGH": "⚠️", "MEDIUM": "🔵", "LOW": "ℹ️"}
SEV_COLOR  = {"CRITICAL": "#f85149", "HIGH": "#d29922",
              "MEDIUM": "#58a6ff",   "LOW":  "#3fb950"}
SEV_SLACK  = {"CRITICAL": "danger", "HIGH": "warning",
              "MEDIUM":   "good",   "LOW":  "good"}


def _is_rate_limited(key: str) -> bool:
    last = _sent_cache.get(key, 0)
    if time.time() - last < RATE_LIMIT_SEC:
        return True
    _sent_cache[key] = time.time()
    return False


def _record(channel: str, incident: dict, status: str, error: str = ""):
    with _history_lock:
        _alert_history.append({
            "channel":   channel,
            "incident":  incident.get("number", ""),
            "severity":  incident.get("severity", ""),
            "threat":    incident.get("threat_type", ""),
            "status":    status,
            "error":     error,
            "timestamp": datetime.utcnow().isoformat(),
        })


# ── Slack ─────────────────────────────────────────────────────

def _build_slack_payload(incident: dict) -> dict:
    sev     = incident.get("severity", "HIGH")
    emoji   = SEV_EMOJI.get(sev, "⚠️")
    color   = SEV_COLOR.get(sev, "#d29922")
    slk_col = SEV_SLACK.get(sev, "warning")

    controls = ", ".join(
        c.get("id", "") for c in incident.get("iso_controls", [])
    ) or "None"

    actions_text = "\n".join(
        f"• {a}" for a in incident.get("iso_actions", [])[:4]
    ) or "See dashboard for details"

    return {
        "text": f"{emoji} *{sev} SOC ALERT* — {incident.get('number', '')}",
        "attachments": [
            {
                "color": color,
                "blocks": [
                    {
                        "type": "header",
                        "text": {
                            "type": "plain_text",
                            "text": f"{emoji} {sev} — {incident.get('threat_type', 'Unknown Threat')}",
                        },
                    },
                    {
                        "type": "section",
                        "fields": [
                            {"type": "mrkdwn", "text": f"*Incident:*\n`{incident.get('number', '')}`"},
                            {"type": "mrkdwn", "text": f"*Source IP:*\n`{incident.get('source_ip', '—')}`"},
                            {"type": "mrkdwn", "text": f"*AI Confidence:*\n{incident.get('confidence', 0):.0f}%"},
                            {"type": "mrkdwn", "text": f"*Status:*\n{incident.get('status', 'Open')}"},
                            {"type": "mrkdwn", "text": f"*ISO 27001 Controls:*\n{controls}"},
                            {"type": "mrkdwn", "text": f"*Detected:*\n{(incident.get('created_at','') or '')[:16].replace('T',' ')} UTC"},
                        ],
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*ISO 27001 Finding:*\n_{incident.get('iso_finding', '')}_",
                        },
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*Recommended Actions:*\n{actions_text}",
                        },
                    },
                    {"type": "divider"},
                    {
                        "type": "context",
                        "elements": [
                            {
                                "type": "mrkdwn",
                                "text": "SOC Automation Platform | ISO 27001:2022 | AI-Driven",
                            }
                        ],
                    },
                ],
            }
        ],
    }


def send_slack_alert(incident: dict, webhook_url: str = None) -> dict:
    url = webhook_url or os.getenv("SLACK_WEBHOOK_URL", "")
    if not url:
        return {"status": "skipped", "reason": "SLACK_WEBHOOK_URL not set in .env"}

    key = f"slack_{incident.get('number','')}"
    if _is_rate_limited(key):
        return {"status": "skipped", "reason": "rate_limited"}

    sev = incident.get("severity", "")
    if sev not in ("CRITICAL", "HIGH"):
        return {"status": "skipped", "reason": "below_threshold"}

    try:
        payload  = _build_slack_payload(incident)
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        _record("slack", incident, "sent")
        return {"status": "sent", "channel": "slack"}
    except requests.exceptions.RequestException as e:
        _record("slack", incident, "error", str(e))
        return {"status": "error", "reason": str(e)}


def test_slack(webhook_url: str = None) -> dict:
    url = webhook_url or os.getenv("SLACK_WEBHOOK_URL", "")
    if not url:
        return {"status": "not_configured",
                "message": "Set SLACK_WEBHOOK_URL in .env"}
    try:
        payload  = {"text": "✅ SOC Platform — Slack integration test successful. "
                            "You will receive CRITICAL and HIGH incident alerts here."}
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        return {"status": "ok", "message": "Test message sent to Slack"}
    except Exception as e:
        return {"status": "error", "reason": str(e)}


# ── Microsoft Teams ───────────────────────────────────────────

def _build_teams_payload(incident: dict) -> dict:
    sev     = incident.get("severity", "HIGH")
    emoji   = SEV_EMOJI.get(sev, "⚠️")
    color   = SEV_COLOR.get(sev, "#d29922").replace("#", "")

    controls = ", ".join(
        c.get("id", "") for c in incident.get("iso_controls", [])
    ) or "None"

    facts = [
        {"name": "Incident ID",     "value": incident.get("number", "")},
        {"name": "Threat type",     "value": incident.get("threat_type", "")},
        {"name": "Severity",        "value": sev},
        {"name": "Source IP",       "value": incident.get("source_ip", "—")},
        {"name": "AI confidence",   "value": f"{incident.get('confidence', 0):.0f}%"},
        {"name": "ISO 27001",       "value": controls},
        {"name": "Detected at",     "value": (incident.get("created_at","") or "")[:16].replace("T"," ") + " UTC"},
    ]

    actions_text = "\n".join(
        f"• {a}" for a in incident.get("iso_actions", [])[:4]
    )

    return {
        "@type":      "MessageCard",
        "@context":   "http://schema.org/extensions",
        "themeColor": color,
        "summary":    f"{sev} SOC Alert: {incident.get('threat_type','')}",
        "sections": [
            {
                "activityTitle":    f"{emoji} **{sev} SOC ALERT — {incident.get('number','')}**",
                "activitySubtitle": incident.get("title", ""),
                "activityText":     incident.get("iso_finding", ""),
                "facts":            facts,
            },
            {
                "title": "Recommended Actions",
                "text":  actions_text or "See dashboard for details",
            },
        ],
        "potentialAction": [
            {
                "@type": "OpenUri",
                "name":  "Open SOC Dashboard",
                "targets": [{"os": "default", "uri": "http://your-soc-server/"}],
            }
        ],
    }


def send_teams_alert(incident: dict, webhook_url: str = None) -> dict:
    url = webhook_url or os.getenv("TEAMS_WEBHOOK_URL", "")
    if not url:
        return {"status": "skipped", "reason": "TEAMS_WEBHOOK_URL not set in .env"}

    key = f"teams_{incident.get('number','')}"
    if _is_rate_limited(key):
        return {"status": "skipped", "reason": "rate_limited"}

    sev = incident.get("severity", "")
    if sev not in ("CRITICAL", "HIGH"):
        return {"status": "skipped", "reason": "below_threshold"}

    try:
        payload  = _build_teams_payload(incident)
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        _record("teams", incident, "sent")
        return {"status": "sent", "channel": "teams"}
    except requests.exceptions.RequestException as e:
        _record("teams", incident, "error", str(e))
        return {"status": "error", "reason": str(e)}


def test_teams(webhook_url: str = None) -> dict:
    url = webhook_url or os.getenv("TEAMS_WEBHOOK_URL", "")
    if not url:
        return {"status": "not_configured",
                "message": "Set TEAMS_WEBHOOK_URL in .env"}
    try:
        payload = {
            "@type":      "MessageCard",
            "@context":   "http://schema.org/extensions",
            "themeColor": "3fb950",
            "summary":    "SOC Platform test",
            "sections": [{"activityTitle": "✅ SOC Platform — Teams integration test",
                           "activityText": "You will receive CRITICAL and HIGH alerts here."}],
        }
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        return {"status": "ok", "message": "Test message sent to Teams"}
    except Exception as e:
        return {"status": "error", "reason": str(e)}


# ── Combined send (fires both if configured) ──────────────────

def send_all_alerts(incident: dict) -> dict:
    """Send to all configured channels simultaneously."""
    results = {}
    threads = []

    def _send(fn, name):
        results[name] = fn(incident)

    for fn, name in [(send_slack_alert, "slack"),
                     (send_teams_alert, "teams")]:
        t = threading.Thread(target=_send, args=(fn, name), daemon=True)
        threads.append(t)
        t.start()

    for t in threads:
        t.join(timeout=15)

    return results


def get_alert_history(limit: int = 50) -> list:
    with _history_lock:
        return list(reversed(list(_alert_history)))[:limit]


def get_integration_status() -> dict:
    return {
        "slack": {
            "configured": bool(os.getenv("SLACK_WEBHOOK_URL")),
            "url_preview": (os.getenv("SLACK_WEBHOOK_URL", "")[:40] + "...")
                            if os.getenv("SLACK_WEBHOOK_URL") else "Not set",
        },
        "teams": {
            "configured": bool(os.getenv("TEAMS_WEBHOOK_URL")),
            "url_preview": (os.getenv("TEAMS_WEBHOOK_URL", "")[:40] + "...")
                            if os.getenv("TEAMS_WEBHOOK_URL") else "Not set",
        },
    }
