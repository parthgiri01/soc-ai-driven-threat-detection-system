"""
Real Data Ingestion — Production SaaS
Replaces ALL simulation. Accepts real events from:
  1. Winlogbeat agents (Windows Event Log)
  2. Syslog forwarders (Linux/router/firewall)
  3. Filebeat (log files)
  4. Direct API (custom scripts)

All authenticated with AgentToken per tenant.
No simulated data anywhere.
"""
import os, re, json, socket, threading, logging
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)

# Per-tenant event buffer (in-memory ring buffer, flushed to DB)
_tenant_buffers = defaultdict(list)
_buffer_lock    = threading.Lock()
MAX_BUFFER      = 1000

# Brute force tracking per tenant
_login_fails    = defaultdict(lambda: defaultdict(int))


# ── Syslog parsing ────────────────────────────────────────────

SEVERITY_MAP = {0:"CRITICAL",1:"CRITICAL",2:"CRITICAL",3:"HIGH",
                4:"MEDIUM",5:"LOW",6:"LOW",7:"LOW"}

SYSLOG_THREATS = [
    (re.compile(r'failed password|authentication failure|invalid user', re.I),
     "Brute Force SSH","HIGH", 85.0),
    (re.compile(r'UFW BLOCK|iptables.*DROP|DENY.*TCP|DENY.*UDP', re.I),
     "Firewall Block","MEDIUM", 65.0),
    (re.compile(r'malware|virus|trojan|ransomware|backdoor', re.I),
     "Malware Detected","CRITICAL", 95.0),
    (re.compile(r'sql.?injection|union.*select|XSS|<script', re.I),
     "Web Attack","HIGH", 80.0),
    (re.compile(r'nmap|masscan|port.?scan|nikto', re.I),
     "Recon / Port Scan","HIGH", 75.0),
    (re.compile(r'useradd|adduser|usermod.*-G.*sudo', re.I),
     "Account Modification","MEDIUM", 70.0),
    (re.compile(r'sudo:.*COMMAND=|privilege.*escalat', re.I),
     "Privilege Escalation","HIGH", 75.0),
    (re.compile(r'segfault|kernel panic|oom.?killer', re.I),
     "System Anomaly","MEDIUM", 55.0),
    (re.compile(r'wget|curl.*http|nc -e|bash -i', re.I),
     "C2 / Download","CRITICAL", 90.0),
]

RFC3164 = re.compile(r'<(\d+)>(\w{3}\s+\d+\s+[\d:]+)\s+(\S+)\s+([^:]+):\s*(.*)')
RFC5424 = re.compile(r'<(\d+)>1\s+(\S+)\s+(\S+)\s+(\S+)\s+\S+\s+\S+\s*(.*)')


def parse_syslog(raw: str, source_ip: str = "") -> dict:
    raw = raw.strip()
    hostname, app, msg, sev_num = "unknown", "unknown", raw, 6

    m = RFC5424.match(raw)
    if m:
        sev_num  = int(m.group(1)) & 7
        hostname = m.group(3)
        app      = m.group(4)
        msg      = m.group(5).strip()
    else:
        m = RFC3164.match(raw)
        if m:
            sev_num  = int(m.group(1)) & 7
            hostname = m.group(3)
            app      = m.group(4).strip()
            msg      = m.group(5).strip()

    soc_sev    = SEVERITY_MAP.get(sev_num, "LOW")
    threat_type = "Normal"
    confidence  = 10.0
    is_threat   = False

    for pattern, ttype, psev, pconf in SYSLOG_THREATS:
        if pattern.search(msg):
            threat_type = ttype
            soc_sev     = psev
            confidence  = pconf
            is_threat   = True
            break

    # Escalate EMERGENCY/ALERT/CRITICAL syslog severity
    if sev_num <= 2 and not is_threat:
        is_threat   = True
        soc_sev     = "CRITICAL"
        confidence  = 80.0
        threat_type = "Critical System Event"

    return {
        "source_type": "syslog",
        "hostname":    hostname,
        "source_ip":   source_ip or hostname,
        "app":         app,
        "message":     msg[:500],
        "raw":         raw[:500],
        "threat_type": threat_type,
        "severity":    soc_sev,
        "is_threat":   is_threat,
        "confidence":  confidence,
        "timestamp":   datetime.utcnow().isoformat(),
        "model":       "Syslog Parser",
    }


# ── Windows Event Log parsing ─────────────────────────────────

WIN_EVENT_MAP = {
    4624:  ("Successful Login",          "LOW",      False, 20.0),
    4625:  ("Failed Login",              "HIGH",     True,  75.0),
    4648:  ("Explicit Credential Login", "HIGH",     True,  70.0),
    4672:  ("Admin Privilege Assigned",  "HIGH",     True,  80.0),
    4688:  ("New Process Created",       "LOW",      False, 15.0),
    4698:  ("Scheduled Task Created",    "MEDIUM",   True,  65.0),
    4720:  ("User Account Created",      "MEDIUM",   True,  70.0),
    4724:  ("Password Reset Attempt",    "MEDIUM",   True,  65.0),
    4725:  ("User Account Disabled",     "MEDIUM",   True,  60.0),
    4726:  ("User Account Deleted",      "HIGH",     True,  80.0),
    4732:  ("User Added to Group",       "MEDIUM",   True,  65.0),
    4740:  ("Account Locked Out",        "HIGH",     True,  85.0),
    4756:  ("Security Group Member Added","HIGH",    True,  75.0),
    4771:  ("Kerberos Pre-Auth Failed",  "HIGH",     True,  80.0),
    7045:  ("New Service Installed",     "HIGH",     True,  80.0),
    1102:  ("Audit Log Cleared",         "CRITICAL", True,  99.0),
    4657:  ("Registry Value Modified",   "MEDIUM",   True,  60.0),
    5140:  ("Network Share Accessed",    "MEDIUM",   False, 40.0),
    4776:  ("NTLM Auth Attempted",       "MEDIUM",   False, 45.0),
}

SUSPICIOUS_PROCESSES = re.compile(
    r'mimikatz|procdump|psexec|cobalt.?strike|metasploit|meterpreter|'
    r'powershell.*-enc|powershell.*bypass|wscript|cscript|certutil.*-decode',
    re.I
)


def parse_winlogbeat(raw: dict, tenant_id: int = None) -> dict:
    """Parse a Winlogbeat JSON event into SOC incident format."""
    # Handle both Winlogbeat 7 and 8 formats
    event_id   = int(raw.get("event",{}).get("code",
                    raw.get("winlog",{}).get("event_id",
                    raw.get("EventID", 0))) or 0)
    hostname   = (raw.get("host",{}).get("name") or
                  raw.get("winlog",{}).get("computer_name","unknown"))
    user       = (raw.get("winlog",{}).get("event_data",{}).get("TargetUserName") or
                  raw.get("winlog",{}).get("user",{}).get("name","SYSTEM") or "SYSTEM")
    src_ip     = (raw.get("winlog",{}).get("event_data",{}).get("IpAddress","") or
                  raw.get("source_ip","") or "")
    process    = (raw.get("winlog",{}).get("event_data",{}).get("NewProcessName","") or
                  raw.get("winlog",{}).get("event_data",{}).get("ProcessName",""))
    message    = raw.get("message","")[:300]

    label, sev, is_threat, conf = WIN_EVENT_MAP.get(
        event_id, ("Windows Event", "LOW", False, 20.0))

    # Brute force detection
    if event_id == 4625 and src_ip and tenant_id:
        _login_fails[tenant_id][src_ip] += 1
        if _login_fails[tenant_id][src_ip] >= 5:
            label     = "Brute Force Attack"
            sev       = "CRITICAL"
            is_threat = True
            conf      = 95.0

    # Suspicious process
    if process and SUSPICIOUS_PROCESSES.search(process):
        label     = f"Suspicious Process: {process.split(chr(92))[-1][:40]}"
        sev       = "CRITICAL"
        is_threat = True
        conf      = 92.0

    # Audit log cleared — always critical
    if event_id == 1102:
        label     = "Audit Log Cleared — Possible Cover-Up"
        sev       = "CRITICAL"
        is_threat = True
        conf      = 99.0

    return {
        "source_type": "winlog",
        "event_id":    event_id,
        "hostname":    hostname,
        "source_ip":   src_ip or hostname,
        "user":        user,
        "process":     process,
        "message":     message,
        "raw":         f"EventID {event_id}: {label} on {hostname} by {user}",
        "threat_type": label,
        "severity":    sev,
        "is_threat":   is_threat,
        "confidence":  conf,
        "timestamp":   datetime.utcnow().isoformat(),
        "model":       "Windows Event Log",
    }


def parse_generic_log(raw: str, source_ip: str = "") -> dict:
    """Parse any plain-text log line using AI engine."""
    try:
        import sys
        sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
        from models.ai_engine import load_model, predict, build_features
        bundle = load_model()
        feats  = build_features({
            "proto":"tcp","flag":"SF","service":"other",
            "src_bytes":len(raw),"dst_bytes":0,
            "count":1,"serror_rate":0,"rerror_rate":0
        }, bundle)
        result = predict(feats, bundle)
        return {
            "source_type": "log",
            "source_ip":   source_ip or "unknown",
            "hostname":    source_ip or "unknown",
            "raw":         raw[:500],
            "message":     raw[:300],
            "threat_type": result.get("threat_type","Unknown"),
            "severity":    result.get("severity","LOW"),
            "is_threat":   result.get("is_threat",False),
            "confidence":  result.get("confidence",20.0),
            "timestamp":   datetime.utcnow().isoformat(),
            "model":       "AI Engine",
        }
    except Exception:
        return {
            "source_type":"log","source_ip":source_ip or "unknown",
            "hostname":source_ip or "unknown","raw":raw[:500],
            "message":raw[:300],"threat_type":"Unknown",
            "severity":"LOW","is_threat":False,"confidence":10.0,
            "timestamp":datetime.utcnow().isoformat(),"model":"Log Parser",
        }


def buffer_event(tenant_id: int, event: dict):
    """Add parsed event to tenant's in-memory buffer."""
    with _buffer_lock:
        buf = _tenant_buffers[tenant_id]
        buf.append(event)
        if len(buf) > MAX_BUFFER:
            buf.pop(0)


def get_tenant_events(tenant_id: int, limit: int = 100) -> list:
    with _buffer_lock:
        return list(reversed(_tenant_buffers[tenant_id][-limit:]))


def flush_threats_to_db(tenant_id: int, app_ctx) -> int:
    """Move buffered threats into PostgreSQL incidents. Returns count created."""
    from models.database import db, Incident, IncidentTimeline
    from models.iso27001 import get_control_details
    import json as _json

    with _buffer_lock:
        events = [e for e in _tenant_buffers[tenant_id] if e.get("is_threat")]
        _tenant_buffers[tenant_id] = [e for e in _tenant_buffers[tenant_id] if not e.get("is_threat")]

    if not events:
        return 0

    created = 0
    with app_ctx:
        for e in events:
            # Deduplicate: skip if same IP+threat open in last hour
            existing = Incident.query.filter_by(
                tenant_id=tenant_id,
                source_ip=e.get("source_ip",""),
                threat_type=e.get("threat_type",""),
                status="Open"
            ).first()
            if existing:
                continue

            iso   = get_control_details(e.get("threat_type","Unknown"))
            count = Incident.query.filter_by(tenant_id=tenant_id).count()
            inc   = Incident(
                tenant_id   = tenant_id,
                number      = f"INC-{count+1:04d}",
                title       = f"{e.get('threat_type','Unknown')} — {e.get('source_ip','unknown')}",
                threat_type = e.get("threat_type","Unknown"),
                severity    = e.get("severity","MEDIUM"),
                confidence  = float(e.get("confidence",0)),
                source_ip   = e.get("source_ip",""),
                dest_ip     = e.get("dest_ip",""),
                raw_event   = e.get("raw","")[:500],
                source_type = e.get("source_type","network"),
                hostname    = e.get("hostname",""),
                agent_id    = e.get("agent_id",""),
                model_used  = e.get("model","AI"),
                iso_controls= _json.dumps(iso["controls_triggered"]),
                iso_finding = iso["finding"],
                iso_actions = _json.dumps(iso["recommended_actions"]),
                evidence    = _json.dumps(iso["evidence_required"]),
            )
            db.session.add(inc)
            db.session.flush()
            db.session.add(IncidentTimeline(
                incident_id=inc.id,
                action=f"Real event ingested via {e.get('source_type','unknown')} — {e.get('model','AI')}",
                actor="System"
            ))
            created += 1

        if created:
            db.session.commit()

    return created
