"""
SOC SaaS Platform — Production Multi-Tenant Application
Real data only. No simulation. PostgreSQL. Stripe billing.
"""
import os, sys, json, threading, secrets
from datetime import datetime, timedelta
from functools import wraps
from io import BytesIO

from dotenv import load_dotenv
load_dotenv()

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import (Flask, render_template, jsonify, request,
                   redirect, url_for, session, g, send_file)
from flask_login  import (LoginManager, login_user, logout_user,
                           login_required, current_user)
from flask_socketio import SocketIO, join_room

from models.database import (db, bcrypt, Tenant, TenantUser, Incident,
                               IncidentNote, IncidentTimeline, AuditLog,
                               AgentToken, Subscription, SuperAdmin)
from utils.ingestion import (parse_syslog, parse_winlogbeat,
                              parse_generic_log, buffer_event,
                              get_tenant_events, flush_threats_to_db)

try:
    import stripe
    stripe.api_key = os.getenv("STRIPE_SECRET_KEY","")
    STRIPE_OK = bool(stripe.api_key)
except ImportError:
    STRIPE_OK = False

try:
    from models.iso27001 import get_control_details, score_compliance, generate_compliance_report
    ISO_OK = True
except ImportError:
    ISO_OK = False

try:
    from utils.pdf_reports import generate_compliance_pdf, generate_incident_pdf, is_available as pdf_ok
    PDF_OK = pdf_ok()
except ImportError:
    PDF_OK = False


# ── Plans ─────────────────────────────────────────────────────
PLANS = {
    "starter":    {"name":"Starter",    "price_gbp":99,  "agents":2,  "incidents":500,  "users":3},
    "pro":        {"name":"Pro",        "price_gbp":199, "agents":10, "incidents":5000, "users":10},
    "enterprise": {"name":"Enterprise", "price_gbp":499, "agents":50, "incidents":None, "users":None},
}


# ── App factory ────────────────────────────────────────────────
def create_app():
    app = Flask(__name__)

    app.config["SECRET_KEY"]                   = os.getenv("SECRET_KEY", secrets.token_hex(32))
    app.config["SQLALCHEMY_DATABASE_URI"]      = os.getenv(
        "DATABASE_URL", "sqlite:///soc_saas.db").replace("postgres://","postgresql://")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"]    = {
        "pool_size": 10, "pool_recycle": 300, "pool_pre_ping": True}
    app.config["REMEMBER_COOKIE_DURATION"]     = timedelta(days=7)
    app.config["SESSION_COOKIE_HTTPONLY"]      = True
    app.config["SESSION_COOKIE_SAMESITE"]      = "Lax"
    app.config["SESSION_COOKIE_SECURE"]        = os.getenv("HTTPS_ENABLED","false")=="true"

    db.init_app(app)
    bcrypt.init_app(app)

    login_manager = LoginManager(app)
    login_manager.login_view = "auth.login"

    @login_manager.user_loader
    def load_user(user_id):
        if user_id and user_id.startswith("superadmin:"):
            return db.session.get(SuperAdmin, int(user_id.split(":")[1]))
        try:
            return db.session.get(TenantUser, int(user_id))
        except Exception:
            return None

    with app.app_context():
        db.create_all()
        _seed_superadmin()

    return app


def _seed_superadmin():
    email = os.getenv("SUPERADMIN_EMAIL", "admin@yoursoc.com")
    if not SuperAdmin.query.filter_by(email=email).first():
        sa = SuperAdmin(email=email)
        sa.set_password(os.getenv("SUPERADMIN_PASSWORD", "SuperAdmin123!"))
        db.session.add(sa)
        db.session.commit()
        print(f"[INIT] Super admin created: {email}")


app      = create_app()
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")


# ── Tenant context middleware ─────────────────────────────────
@app.before_request
def load_tenant():
    g.tenant = None
    if current_user.is_authenticated and isinstance(current_user, TenantUser):
        g.tenant = current_user.tenant


def tenant_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not g.tenant:
            return jsonify({"error":"No tenant context"}), 403
        if not g.tenant.is_active:
            return jsonify({"error":"Account suspended"}), 403
        return f(*args, **kwargs)
    return decorated


def role_required(*roles):
    def decorator(f):
        @wraps(f)
        @tenant_required
        def decorated(*args, **kwargs):
            if current_user.role not in roles:
                return jsonify({"error":"Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


def superadmin_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not isinstance(current_user, SuperAdmin):
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return decorated


def audit(action, target=""):
    if g.get("tenant") and current_user.is_authenticated:
        log = AuditLog(
            tenant_id  = g.tenant.id,
            user_id    = current_user.id if isinstance(current_user, TenantUser) else None,
            username   = current_user.email,
            action     = action,
            target     = target,
            ip_address = request.remote_addr,
        )
        db.session.add(log)
        db.session.commit()


# ── Auth blueprint ────────────────────────────────────────────
from flask import Blueprint
auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

@auth_bp.route("/login", methods=["GET","POST"])
def login():
    if current_user.is_authenticated:
        if isinstance(current_user, SuperAdmin):
            return redirect(url_for("superadmin.dashboard"))
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email    = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        remember = bool(request.form.get("remember"))

        # Try super admin first
        sa = SuperAdmin.query.filter_by(email=email).first()
        if sa and sa.check_password(password):
            login_user(sa, remember=remember)
            return redirect(url_for("superadmin.dashboard"))

        # Try tenant user
        user = TenantUser.query.filter_by(email=email).first()
        if user and user.is_active and user.check_password(password):
            if not user.tenant.is_active:
                return render_template("login.html", error="Account suspended. Contact support.")
            login_user(user, remember=remember)
            user.last_login = datetime.utcnow()
            db.session.commit()
            return redirect(request.form.get("next","") or url_for("dashboard"))

        return render_template("login.html", error="Invalid email or password.")

    return render_template("login.html", next=request.args.get("next",""))

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))

@auth_bp.route("/register", methods=["GET","POST"])
def register():
    """Self-service signup for new client companies."""
    if request.method == "POST":
        company = request.form.get("company","").strip()
        email   = request.form.get("email","").strip().lower()
        password= request.form.get("password","")
        if not company or not email or not password:
            return render_template("register.html", error="All fields required.")
        if TenantUser.query.filter_by(email=email).first():
            return render_template("register.html", error="Email already registered.")

        from slugify import slugify
        slug = slugify(company)
        base = slug
        i = 1
        while Tenant.query.filter_by(slug=slug).first():
            slug = f"{base}-{i}"; i += 1

        # Create tenant with 14-day trial
        tenant = Tenant(
            name       = company,
            slug       = slug,
            plan       = "starter",
            subscription_status = "trialing",
            trial_ends_at = datetime.utcnow() + timedelta(days=14),
        )
        db.session.add(tenant)
        db.session.flush()

        # Create admin user for this tenant
        user = TenantUser(
            tenant_id = tenant.id,
            username  = email.split("@")[0],
            email     = email,
            role      = "admin",
        )
        user.set_password(password)
        db.session.add(user)

        # Create default agent token
        token = AgentToken(
            tenant_id   = tenant.id,
            token       = AgentToken.generate(),
            name        = "Default agent",
            description = "Auto-generated on signup",
        )
        db.session.add(token)
        db.session.commit()

        login_user(user)
        return redirect(url_for("onboarding"))

    return render_template("register.html")

@auth_bp.route("/change-password", methods=["POST"])
@login_required
def change_password():
    data = request.get_json()
    if not isinstance(current_user, TenantUser):
        return jsonify({"error":"Not allowed"}), 400
    if not current_user.check_password(data.get("current_password","")):
        return jsonify({"error":"Current password incorrect"}), 400
    new_pw = data.get("new_password","")
    if len(new_pw) < 8:
        return jsonify({"error":"Minimum 8 characters"}), 400
    current_user.set_password(new_pw)
    db.session.commit()
    return jsonify({"success":True})

app.register_blueprint(auth_bp)


# ── Main dashboard ────────────────────────────────────────────
@app.route("/")
@tenant_required
def dashboard():
    return render_template("dashboard.html",
                           tenant=g.tenant,
                           user=current_user,
                           plan=PLANS.get(g.tenant.plan, PLANS["starter"]))


@app.route("/onboarding")
@login_required
def onboarding():
    if not isinstance(current_user, TenantUser):
        return redirect(url_for("dashboard"))
    tokens = AgentToken.query.filter_by(tenant_id=g.tenant.id).all()
    return render_template("onboarding.html",
                           tenant=g.tenant,
                           tokens=tokens,
                           server_ip=os.getenv("SERVER_IP","your-server-ip"),
                           syslog_port=os.getenv("SYSLOG_PORT","5140"))


# ── Tenant API ────────────────────────────────────────────────
@app.route("/api/me")
@tenant_required
def api_me():
    return jsonify({
        "user":   {"email":current_user.email,"role":current_user.role,"username":current_user.username},
        "tenant": {"name":g.tenant.name,"slug":g.tenant.slug,"plan":g.tenant.plan,
                   "subscription_status":g.tenant.subscription_status},
        "plan":   PLANS.get(g.tenant.plan, PLANS["starter"]),
    })


# ── Incidents ─────────────────────────────────────────────────
@app.route("/api/incidents")
@tenant_required
def api_incidents():
    q = Incident.query.filter_by(tenant_id=g.tenant.id).order_by(Incident.created_at.desc())
    if request.args.get("status"):  q = q.filter_by(status=request.args["status"])
    if request.args.get("severity"):q = q.filter_by(severity=request.args["severity"])
    incidents = q.limit(int(request.args.get("limit",200))).all()
    return jsonify([i.to_dict() for i in incidents])


@app.route("/api/incidents/<inc_id>")
@tenant_required
def api_incident(inc_id):
    inc = Incident.query.filter_by(tenant_id=g.tenant.id, number=inc_id).first()
    if not inc: return jsonify({"error":"Not found"}),404
    d = inc.to_dict()
    if ISO_OK: d["iso_detail"] = get_control_details(inc.threat_type)
    return jsonify(d)


@app.route("/api/incidents/<inc_id>/status", methods=["POST"])
@role_required("admin","analyst")
def api_update_status(inc_id):
    inc = Incident.query.filter_by(tenant_id=g.tenant.id, number=inc_id).first()
    if not inc: return jsonify({"error":"Not found"}),404
    data = request.get_json()
    old  = inc.status
    inc.status     = data.get("status","Open")
    inc.updated_at = datetime.utcnow()
    if inc.status == "Resolved":
        inc.resolved_at = datetime.utcnow()
    note = data.get("note","")
    if note:
        db.session.add(IncidentNote(incident_id=inc.id, text=note, actor=current_user.username))
    db.session.add(IncidentTimeline(
        incident_id=inc.id,
        action=f"Status: {old} → {inc.status}",
        actor=current_user.username, note=note or None))
    db.session.commit()
    audit(f"Incident {inc_id} status → {inc.status}", inc_id)
    return jsonify(inc.to_dict())


@app.route("/api/incidents/<inc_id>/note", methods=["POST"])
@role_required("admin","analyst")
def api_add_note(inc_id):
    inc = Incident.query.filter_by(tenant_id=g.tenant.id, number=inc_id).first()
    if not inc: return jsonify({"error":"Not found"}),404
    note = request.get_json().get("note","")
    db.session.add(IncidentNote(incident_id=inc.id, text=note, actor=current_user.username))
    db.session.add(IncidentTimeline(incident_id=inc.id,
        action=f"Note: {note[:60]}", actor=current_user.username))
    inc.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify(inc.to_dict())


@app.route("/api/stats")
@tenant_required
def api_stats():
    from sqlalchemy import func
    t  = g.tenant.id
    total = Incident.query.filter_by(tenant_id=t).count()
    open_ = Incident.query.filter_by(tenant_id=t, status="Open").count()
    res   = Incident.query.filter_by(tenant_id=t, status="Resolved").count()
    crit  = Incident.query.filter_by(tenant_id=t, severity="CRITICAL").count()
    high  = Incident.query.filter_by(tenant_id=t, severity="HIGH").count()
    events= get_tenant_events(t, 10)
    stats = {"total":total,"open":open_,"resolved":res,"critical":crit,"high":high,
             "recent_events":len(events),"live_events":events[:5]}
    if ISO_OK:
        incidents = [i.to_dict() for i in Incident.query.filter_by(tenant_id=t).limit(200).all()]
        stats["compliance"] = score_compliance(incidents)
    return jsonify(stats)


# ── REAL data ingestion API ───────────────────────────────────

def _verify_token(req) -> AgentToken | None:
    """Verify Bearer token from Authorization header."""
    auth = req.headers.get("Authorization","")
    if not auth.startswith("Bearer "):
        return None
    token_str = auth[7:].strip()
    token = AgentToken.query.filter_by(token=token_str, is_active=True).first()
    if token:
        token.last_seen   = datetime.utcnow()
        token.event_count += 1
        db.session.commit()
    return token


@app.route("/ingest/syslog", methods=["POST"])
def ingest_syslog():
    """
    Receive syslog events from rsyslog/syslog-ng forwarders.
    Header: Authorization: Bearer YOUR_AGENT_TOKEN
    Body: raw syslog line (text/plain) or JSON array of lines
    """
    token = _verify_token(request)
    if not token:
        return jsonify({"error":"Invalid or missing agent token"}), 401

    ct = request.content_type or ""
    if "json" in ct:
        lines = request.get_json(force=True)
        if isinstance(lines, str): lines = [lines]
        elif isinstance(lines, dict): lines = [lines.get("message","")]
    else:
        lines = [request.get_data(as_text=True)]

    ingested = 0
    for raw in lines:
        if not raw or not raw.strip(): continue
        event = parse_syslog(raw, request.remote_addr)
        event["agent_id"] = str(token.id)
        buffer_event(token.tenant_id, event)
        ingested += 1

    # Flush threats to DB asynchronously
    threading.Thread(
        target=flush_threats_to_db,
        args=(token.tenant_id, app.app_context()),
        daemon=True
    ).start()

    return jsonify({"status":"ok","ingested":ingested}), 200


@app.route("/ingest/winlogbeat", methods=["POST"])
def ingest_winlogbeat():
    """
    Receive Windows Event Log from Winlogbeat agents.
    Header: Authorization: Bearer YOUR_AGENT_TOKEN
    Body: Winlogbeat JSON event or array of events
    """
    token = _verify_token(request)
    if not token:
        return jsonify({"error":"Invalid or missing agent token"}), 401

    data = request.get_json(force=True)
    if isinstance(data, dict): data = [data]
    if not isinstance(data, list): data = []

    ingested = 0
    for raw in data:
        if not raw: continue
        event = parse_winlogbeat(raw, token.tenant_id)
        event["agent_id"] = str(token.id)
        buffer_event(token.tenant_id, event)
        ingested += 1

    threading.Thread(
        target=flush_threats_to_db,
        args=(token.tenant_id, app.app_context()),
        daemon=True
    ).start()

    return jsonify({"status":"ok","ingested":ingested}), 200


@app.route("/ingest/logs", methods=["POST"])
def ingest_logs():
    """
    Receive generic log lines (Filebeat, custom scripts).
    Header: Authorization: Bearer YOUR_AGENT_TOKEN
    """
    token = _verify_token(request)
    if not token:
        return jsonify({"error":"Invalid or missing agent token"}), 401

    data = request.get_json(force=True) or {}
    lines = data.get("logs", [data.get("message","")])
    if isinstance(lines, str): lines = [lines]

    ingested = 0
    for line in lines:
        if not line: continue
        event = parse_generic_log(str(line), request.remote_addr)
        event["agent_id"] = str(token.id)
        buffer_event(token.tenant_id, event)
        ingested += 1

    threading.Thread(
        target=flush_threats_to_db,
        args=(token.tenant_id, app.app_context()),
        daemon=True
    ).start()

    return jsonify({"status":"ok","ingested":ingested}), 200


@app.route("/api/events/live")
@tenant_required
def api_live_events():
    """Live event stream from agent buffers (no simulation)."""
    events = get_tenant_events(g.tenant.id, int(request.args.get("limit",50)))
    return jsonify(events)


# ── Agent token management ────────────────────────────────────
@app.route("/api/agents", methods=["GET"])
@tenant_required
def api_agents():
    tokens = AgentToken.query.filter_by(tenant_id=g.tenant.id).all()
    return jsonify([t.to_dict() for t in tokens])


@app.route("/api/agents", methods=["POST"])
@role_required("admin")
def api_create_agent():
    data  = request.get_json()
    token = AgentToken(
        tenant_id   = g.tenant.id,
        token       = AgentToken.generate(),
        name        = data.get("name","Agent"),
        description = data.get("description",""),
    )
    db.session.add(token)
    db.session.commit()
    audit(f"Agent token created: {token.name}")
    # Return full token once — never shown again
    return jsonify({"id":token.id,"name":token.name,
                    "token":token.token,  # full token shown ONCE
                    "note":"Save this token — it will not be shown again"})


@app.route("/api/agents/<int:aid>", methods=["DELETE"])
@role_required("admin")
def api_revoke_agent(aid):
    token = AgentToken.query.filter_by(id=aid, tenant_id=g.tenant.id).first()
    if not token: return jsonify({"error":"Not found"}),404
    token.is_active = False
    db.session.commit()
    audit(f"Agent token revoked: {token.name}")
    return jsonify({"success":True})


# ── Compliance & PDF ──────────────────────────────────────────
@app.route("/api/compliance")
@tenant_required
def api_compliance():
    if not ISO_OK: return jsonify({"error":"ISO module not available"}),503
    incidents = [i.to_dict() for i in
                 Incident.query.filter_by(tenant_id=g.tenant.id).limit(500).all()]
    return jsonify(generate_compliance_report(incidents))


@app.route("/api/reports/compliance.pdf")
@tenant_required
def api_compliance_pdf():
    if not PDF_OK: return jsonify({"error":"ReportLab not installed"}),503
    incidents  = [i.to_dict() for i in Incident.query.filter_by(tenant_id=g.tenant.id).limit(500).all()]
    compliance = generate_compliance_report(incidents)
    pdf        = generate_compliance_pdf(incidents, compliance)
    buf        = BytesIO(pdf); buf.seek(0)
    filename   = f"{g.tenant.slug}_compliance_{datetime.utcnow().strftime('%Y%m%d')}.pdf"
    audit("Compliance PDF downloaded")
    return send_file(buf, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@app.route("/api/reports/incident/<inc_id>.pdf")
@tenant_required
def api_incident_pdf(inc_id):
    if not PDF_OK: return jsonify({"error":"ReportLab not installed"}),503
    inc = Incident.query.filter_by(tenant_id=g.tenant.id, number=inc_id).first()
    if not inc: return jsonify({"error":"Not found"}),404
    pdf = generate_incident_pdf(inc.to_dict())
    buf = BytesIO(pdf); buf.seek(0)
    return send_file(buf, mimetype="application/pdf",
                     as_attachment=True, download_name=f"{inc_id}.pdf")


# ── Stripe billing ────────────────────────────────────────────
@app.route("/api/billing/checkout", methods=["POST"])
@tenant_required
def api_checkout():
    if not STRIPE_OK:
        return jsonify({"error":"Stripe not configured"}),503
    data    = request.get_json()
    plan    = data.get("plan","pro")
    if plan not in PLANS:
        return jsonify({"error":"Invalid plan"}),400

    STRIPE_PRICES = {
        "starter":    os.getenv("STRIPE_PRICE_STARTER"),
        "pro":        os.getenv("STRIPE_PRICE_PRO"),
        "enterprise": os.getenv("STRIPE_PRICE_ENTERPRISE"),
    }
    price_id = STRIPE_PRICES.get(plan)
    if not price_id:
        return jsonify({"error":f"Stripe price not configured for {plan}"}),503

    domain = os.getenv("APP_DOMAIN","http://localhost:5000")
    session_obj = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{"price":price_id,"quantity":1}],
        mode="subscription",
        success_url=f"{domain}/billing/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{domain}/billing/cancel",
        client_reference_id=str(g.tenant.id),
        customer_email=current_user.email,
        metadata={"tenant_id":str(g.tenant.id),"plan":plan},
    )
    return jsonify({"checkout_url":session_obj.url})


@app.route("/billing/webhook", methods=["POST"])
def stripe_webhook():
    """Stripe sends events here when subscription status changes."""
    payload = request.get_data()
    sig     = request.headers.get("Stripe-Signature","")
    secret  = os.getenv("STRIPE_WEBHOOK_SECRET","")

    try:
        event = stripe.Webhook.construct_event(payload, sig, secret)
    except Exception as e:
        return jsonify({"error":str(e)}),400

    if event["type"] == "checkout.session.completed":
        s         = event["data"]["object"]
        tenant_id = int(s.get("client_reference_id",0))
        plan      = s["metadata"].get("plan","starter")
        tenant    = db.session.get(Tenant, tenant_id)
        if tenant:
            tenant.plan                    = plan
            tenant.stripe_customer_id      = s.get("customer")
            tenant.stripe_subscription_id  = s.get("subscription")
            tenant.subscription_status     = "active"
            sub = Subscription.query.filter_by(tenant_id=tenant_id).first()
            if not sub:
                sub = Subscription(tenant_id=tenant_id)
                db.session.add(sub)
            sub.plan         = plan
            sub.status       = "active"
            sub.stripe_sub_id= s.get("subscription")
            sub.amount_pence = PLANS[plan]["price_gbp"] * 100
            db.session.commit()

    elif event["type"] == "customer.subscription.deleted":
        s          = event["data"]["object"]
        cust_id    = s.get("customer")
        tenant     = Tenant.query.filter_by(stripe_customer_id=cust_id).first()
        if tenant:
            tenant.subscription_status = "canceled"
            tenant.is_active           = False
            db.session.commit()

    return jsonify({"status":"ok"})


@app.route("/billing/success")
@login_required
def billing_success():
    return redirect(url_for("dashboard"))


# ── Audit log ─────────────────────────────────────────────────
@app.route("/api/audit")
@role_required("admin")
def api_audit():
    logs = AuditLog.query.filter_by(tenant_id=g.tenant.id)\
           .order_by(AuditLog.timestamp.desc()).limit(100).all()
    return jsonify([l.to_dict() for l in logs])


# ── User management ───────────────────────────────────────────
@app.route("/api/users", methods=["GET"])
@role_required("admin")
def api_users():
    users = TenantUser.query.filter_by(tenant_id=g.tenant.id).all()
    return jsonify([{"id":u.id,"username":u.username,"email":u.email,
                     "role":u.role,"is_active":u.is_active,
                     "last_login":u.last_login.isoformat() if u.last_login else None}
                    for u in users])


@app.route("/api/users", methods=["POST"])
@role_required("admin")
def api_create_user():
    plan_limit = PLANS.get(g.tenant.plan,{}).get("users")
    if plan_limit:
        current_count = TenantUser.query.filter_by(tenant_id=g.tenant.id, is_active=True).count()
        if current_count >= plan_limit:
            return jsonify({"error":f"User limit reached for {g.tenant.plan} plan ({plan_limit} users)"}),403
    data = request.get_json()
    if TenantUser.query.filter_by(email=data["email"]).first():
        return jsonify({"error":"Email already exists"}),400
    u = TenantUser(tenant_id=g.tenant.id, username=data.get("username",data["email"].split("@")[0]),
                   email=data["email"], role=data.get("role","analyst"))
    u.set_password(data["password"])
    db.session.add(u)
    db.session.commit()
    audit(f"User created: {u.email}")
    return jsonify({"success":True,"id":u.id})


@app.route("/api/users/<int:uid>", methods=["PATCH"])
@role_required("admin")
def api_update_user(uid):
    u = TenantUser.query.filter_by(id=uid, tenant_id=g.tenant.id).first()
    if not u: return jsonify({"error":"Not found"}),404
    data = request.get_json()
    if "role"      in data: u.role      = data["role"]
    if "is_active" in data: u.is_active = data["is_active"]
    db.session.commit()
    return jsonify({"success":True})


# ── Health check ──────────────────────────────────────────────
@app.route("/health")
def health():
    try:
        db.session.execute(db.text("SELECT 1"))
        return jsonify({"status":"ok","database":"ok","timestamp":datetime.utcnow().isoformat()})
    except Exception as e:
        return jsonify({"status":"error","database":str(e)}),503


# ── Super Admin panel ─────────────────────────────────────────
superadmin_bp = Blueprint("superadmin", __name__, url_prefix="/admin")

@superadmin_bp.route("/")
@superadmin_required
def dashboard():
    tenants = Tenant.query.order_by(Tenant.created_at.desc()).all()
    total_incidents = Incident.query.count()
    return render_template("superadmin.html",
                           tenants=tenants,
                           total_incidents=total_incidents,
                           plans=PLANS)

@superadmin_bp.route("/api/tenants")
@superadmin_required
def api_tenants():
    tenants = Tenant.query.order_by(Tenant.created_at.desc()).all()
    result  = []
    for t in tenants:
        inc_count   = Incident.query.filter_by(tenant_id=t.id).count()
        user_count  = TenantUser.query.filter_by(tenant_id=t.id).count()
        open_crits  = Incident.query.filter_by(tenant_id=t.id, severity="CRITICAL", status="Open").count()
        result.append({
            "id":t.id,"name":t.name,"slug":t.slug,"plan":t.plan,
            "status":t.subscription_status,"is_active":t.is_active,
            "incidents":inc_count,"users":user_count,"open_critical":open_crits,
            "created_at":t.created_at.isoformat() if t.created_at else "",
        })
    return jsonify(result)

@superadmin_bp.route("/api/tenants/<int:tid>/toggle", methods=["POST"])
@superadmin_required
def toggle_tenant(tid):
    t = db.session.get(Tenant, tid)
    if not t: return jsonify({"error":"Not found"}),404
    t.is_active = not t.is_active
    db.session.commit()
    return jsonify({"success":True,"is_active":t.is_active})

@superadmin_bp.route("/api/stats")
@superadmin_required
def admin_stats():
    return jsonify({
        "total_tenants":  Tenant.query.count(),
        "active_tenants": Tenant.query.filter_by(is_active=True).count(),
        "paid_tenants":   Tenant.query.filter_by(subscription_status="active").count(),
        "trial_tenants":  Tenant.query.filter_by(subscription_status="trialing").count(),
        "total_incidents":Incident.query.count(),
        "total_users":    TenantUser.query.count(),
        "mrr_gbp":        sum(PLANS.get(t.plan,{}).get("price_gbp",0)
                              for t in Tenant.query.filter_by(subscription_status="active").all()),
    })

app.register_blueprint(superadmin_bp)


# ── Live push via WebSocket ───────────────────────────────────
@socketio.on("join")
def on_join(data):
    if current_user.is_authenticated and isinstance(current_user, TenantUser):
        room = f"tenant_{current_user.tenant_id}"
        join_room(room)


def _push_loop():
    import time
    while True:
        try:
            for tenant_id, events in list(_tenant_buffers.items()):
                if events:
                    threats = [e for e in events[-5:] if e.get("is_threat")]
                    if threats:
                        socketio.emit("new_threat", {"threats": threats},
                                      room=f"tenant_{tenant_id}")
        except Exception:
            pass
        time.sleep(3)


threading.Thread(target=_push_loop, daemon=True).start()


if __name__ == "__main__":
    port = int(os.getenv("PORT",5000))
    print(f"\n{'='*60}")
    print(f"  SOC SaaS Platform — Production")
    print(f"  http://0.0.0.0:{port}")
    print(f"  Superadmin: {os.getenv('SUPERADMIN_EMAIL','admin@yoursoc.com')}")
    print(f"{'='*60}\n")
    socketio.run(app, debug=False, host="0.0.0.0", port=port)
