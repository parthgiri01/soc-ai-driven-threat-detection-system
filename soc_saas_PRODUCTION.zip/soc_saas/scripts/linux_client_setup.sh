#!/bin/bash
# ============================================================
# SOC SaaS — Linux Client Setup Script
# Run on client's Linux server to forward logs to your platform
# Usage: bash linux_client_setup.sh YOUR_SERVER_DOMAIN YOUR_TOKEN
# ============================================================

SERVER="$1"   # e.g. yoursoc.co.uk
TOKEN="$2"    # Agent token from your SOC dashboard

if [ -z "$SERVER" ] || [ -z "$TOKEN" ]; then
    echo "Usage: bash linux_client_setup.sh YOUR_SERVER_DOMAIN YOUR_AGENT_TOKEN"
    exit 1
fi

echo "[SOC] Setting up log forwarding to $SERVER..."

# ── Method 1: rsyslog (recommended) ──────────────────────────
if command -v rsyslog &> /dev/null; then
    echo "[SOC] Configuring rsyslog forwarding..."
    cat > /etc/rsyslog.d/99-soc-platform.conf << EOF
# Forward all logs to SOC SaaS platform
*.* action(type="omfwd"
    target="$SERVER"
    port="5140"
    protocol="udp"
    template="RSYSLOG_SyslogProtocol23Format")
EOF
    systemctl restart rsyslog
    echo "[SOC] rsyslog configured — logs forwarding on UDP 5140"
fi

# ── Method 2: Filebeat (for log files) ───────────────────────
if command -v apt-get &> /dev/null; then
    echo "[SOC] Installing Filebeat..."
    wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | apt-key add -
    echo "deb https://artifacts.elastic.co/packages/8.x/apt stable main" > /etc/apt/sources.list.d/elastic-8.x.list
    apt-get update -qq && apt-get install -y filebeat

    cat > /etc/filebeat/filebeat.yml << EOF
filebeat.inputs:
  - type: log
    enabled: true
    paths:
      - /var/log/auth.log
      - /var/log/syslog
      - /var/log/nginx/access.log
      - /var/log/nginx/error.log
      - /var/log/apache2/*.log
    fields:
      agent_token: "$TOKEN"
      server: "$SERVER"

output.http:
  hosts: ["https://$SERVER/ingest/logs"]
  headers:
    Authorization: "Bearer $TOKEN"
  codec.json:
    pretty: false

logging.level: info
EOF
    systemctl enable filebeat
    systemctl start filebeat
    echo "[SOC] Filebeat configured"
fi

echo ""
echo "============================================================"
echo "  Client setup complete!"
echo "  Logs are now forwarding to: $SERVER"
echo "  Token: ${TOKEN:0:8}..."
echo ""
echo "  You should see events appearing in your SOC dashboard"
echo "  within 60 seconds."
echo "============================================================"
