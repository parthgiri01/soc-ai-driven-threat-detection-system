#!/bin/bash
# ============================================================
# SOC SaaS Platform — Full Server Setup Script
# Run on a fresh Ubuntu 24.04 DigitalOcean Droplet
# Usage: curl -sL https://raw.githubusercontent.com/parthgiri01/soc-automation-platform/main/scripts/setup_server.sh | bash
# Or copy this file to server and run: bash setup_server.sh
# ============================================================

set -e  # exit on error
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo ""
echo "============================================================"
echo "  SOC SaaS Platform — Server Setup"
echo "  Ubuntu 24.04 | Docker | Nginx | PostgreSQL | SSL"
echo "============================================================"
echo ""

# ── Collect config ────────────────────────────────────────────
read -p "Your domain name (e.g. yoursoc.co.uk): " DOMAIN
read -p "Your email (for SSL cert + superadmin login): " EMAIL
read -p "Superadmin password: " -s SUPERADMIN_PASS; echo ""
read -p "Database password (make it strong): " -s DB_PASS; echo ""

SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
SERVER_IP=$(curl -s ifconfig.me)

log "Domain: $DOMAIN"
log "Server IP: $SERVER_IP"
log "Starting setup..."

# ── 1. System update ──────────────────────────────────────────
log "Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq

# ── 2. Install Docker ─────────────────────────────────────────
log "Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | bash
    usermod -aG docker ubuntu 2>/dev/null || true
fi
docker --version

# ── 3. Install dependencies ───────────────────────────────────
log "Installing system dependencies..."
apt-get install -y -qq git python3 python3-pip certbot python3-certbot-nginx ufw fail2ban

# ── 4. Install Nginx ──────────────────────────────────────────
log "Installing Nginx..."
apt-get install -y -qq nginx

# ── 5. Firewall ───────────────────────────────────────────────
log "Configuring firewall..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 5140/udp  # Syslog from clients
ufw allow 5044/tcp  # Winlogbeat from clients
ufw --force enable
log "Firewall configured"

# ── 6. Fail2ban ───────────────────────────────────────────────
log "Configuring fail2ban (brute force protection)..."
cat > /etc/fail2ban/jail.local << 'EOF'
[sshd]
enabled = true
bantime = 3600
maxretry = 5

[nginx-http-auth]
enabled = true
maxretry = 5
EOF
systemctl enable fail2ban
systemctl restart fail2ban

# ── 7. Clone/copy application ─────────────────────────────────
log "Setting up application..."
mkdir -p /opt/soc_saas
cd /opt/soc_saas

# If GitHub repo exists, clone it; otherwise assume files are here
if [ -d ".git" ]; then
    git pull
else
    log "Copying application files (run from your local machine)..."
fi

# ── 8. Create .env ────────────────────────────────────────────
log "Creating .env configuration..."
cat > /opt/soc_saas/.env << EOF
# SOC SaaS Platform — Production Environment
SECRET_KEY=$SECRET_KEY
DATABASE_URL=postgresql://socuser:$DB_PASS@postgres:5432/socplatform
SUPERADMIN_EMAIL=$EMAIL
SUPERADMIN_PASSWORD=$SUPERADMIN_PASS
APP_DOMAIN=https://$DOMAIN
SERVER_IP=$SERVER_IP
SYSLOG_PORT=5140

# Add these after getting Stripe keys:
# STRIPE_SECRET_KEY=sk_live_...
# STRIPE_PUBLISHABLE_KEY=pk_live_...
# STRIPE_WEBHOOK_SECRET=whsec_...
# STRIPE_PRICE_STARTER=price_...
# STRIPE_PRICE_PRO=price_...
# STRIPE_PRICE_ENTERPRISE=price_...

# Add after setting up email:
# SMTP_HOST=smtp.gmail.com
# SMTP_PORT=587
# SMTP_USER=your@gmail.com
# SMTP_PASS=your-app-password
# ALERT_EMAIL=alerts@yourcompany.com

FLASK_ENV=production
HTTPS_ENABLED=true
LOG_LEVEL=info
POSTGRES_USER=socuser
POSTGRES_PASSWORD=$DB_PASS
POSTGRES_DB=socplatform
EOF
chmod 600 /opt/soc_saas/.env
log ".env created and secured (600 permissions)"

# ── 9. Docker Compose ─────────────────────────────────────────
log "Creating docker-compose.yml..."
cat > /opt/soc_saas/docker-compose.yml << EOF
version: "3.9"
services:
  soc-platform:
    build: .
    container_name: soc-platform
    restart: unless-stopped
    env_file: .env
    ports:
      - "5000:5000"
      - "5140:5140/udp"
      - "5044:5044"
    depends_on:
      postgres:
        condition: service_healthy
    volumes:
      - soc-reports:/app/reports
      - soc-logs:/app/logs
    networks:
      - soc-net

  postgres:
    image: postgres:16-alpine
    container_name: soc-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: socuser
      POSTGRES_PASSWORD: $DB_PASS
      POSTGRES_DB: socplatform
    volumes:
      - postgres-data:/var/lib/postgresql/data
    networks:
      - soc-net
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U socuser -d socplatform"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  postgres-data:
  soc-reports:
  soc-logs:

networks:
  soc-net:
    driver: bridge
EOF

# ── 10. Nginx config ──────────────────────────────────────────
log "Configuring Nginx..."
cat > /etc/nginx/sites-available/soc-platform << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    http2 on;
    server_name $DOMAIN www.$DOMAIN;

    ssl_certificate     /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;
    add_header Strict-Transport-Security "max-age=63072000" always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;

    client_max_body_size 50M;

    location /auth/login {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://127.0.0.1:5000;
        include /etc/nginx/proxy_params;
    }

    location /ingest/ {
        proxy_pass http://127.0.0.1:5000;
        include /etc/nginx/proxy_params;
    }

    location /socket.io/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_read_timeout 86400;
    }

    location / {
        proxy_pass http://127.0.0.1:5000;
        include /etc/nginx/proxy_params;
    }
}

limit_req_zone \$binary_remote_addr zone=login:10m rate=5r/m;
EOF

cat > /etc/nginx/proxy_params << 'EOF'
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_redirect off;
EOF

ln -sf /etc/nginx/sites-available/soc-platform /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t

# ── 11. SSL certificate ───────────────────────────────────────
log "Getting SSL certificate from Let's Encrypt..."
warn "Make sure DNS is pointing to $SERVER_IP before continuing"
read -p "Press Enter when DNS is ready (or Ctrl+C to skip SSL for now)..."
certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos -m $EMAIL || {
    warn "SSL cert failed — run manually later: certbot --nginx -d $DOMAIN"
}

# ── 12. Build and start ───────────────────────────────────────
log "Building and starting SOC platform..."
cd /opt/soc_saas
docker compose build
docker compose up -d

# ── 13. Auto-renew SSL ────────────────────────────────────────
log "Setting up SSL auto-renewal..."
echo "0 12 * * * root certbot renew --quiet" >> /etc/crontab

# ── 14. Daily backup ──────────────────────────────────────────
log "Setting up daily database backup..."
cat > /etc/cron.daily/soc-backup << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d)
docker exec soc-postgres pg_dump -U socuser socplatform | gzip > /opt/backups/soc_$DATE.sql.gz
find /opt/backups -name "soc_*.sql.gz" -mtime +30 -delete
EOF
chmod +x /etc/cron.daily/soc-backup
mkdir -p /opt/backups

# ── Done ──────────────────────────────────────────────────────
systemctl restart nginx

echo ""
echo "============================================================"
echo -e "${GREEN}  SOC SaaS Platform is LIVE!${NC}"
echo "============================================================"
echo "  URL:           https://$DOMAIN"
echo "  Superadmin:    $EMAIL"
echo "  Admin panel:   https://$DOMAIN/admin"
echo ""
echo "  Client signup: https://$DOMAIN/auth/register"
echo "  Health check:  https://$DOMAIN/health"
echo ""
echo "  Server IP: $SERVER_IP"
echo "  Syslog port:  5140 (UDP) — point client devices here"
echo "  Winlogbeat:   5044 (TCP) — configure in winlogbeat.yml"
echo ""
echo "  Next steps:"
echo "  1. Add Stripe keys to /opt/soc_saas/.env"
echo "  2. Push to GitHub and configure CI/CD"
echo "  3. Log in at https://$DOMAIN/admin"
echo "============================================================"
